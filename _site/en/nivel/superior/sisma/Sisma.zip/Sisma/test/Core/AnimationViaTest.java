/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Core;

import junit.framework.TestCase;

/**
 *
 * @author nickb
 */
public class AnimationViaTest extends TestCase {
    
    public AnimationViaTest(String testName) {
        super(testName);
    }
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }
    
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    /**
     * Test of execute method, of class AnimationVia.
     */
    public void testExecute() {
        System.out.println("execute");
        int tempo = 0;
        AnimationVia instance = null;
        int expResult = 0;
        int result = instance.execute(tempo);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of executionFinished method, of class AnimationVia.
     */
    public void testExecutionFinished() {
        System.out.println("executionFinished");
        AnimationVia instance = null;
        boolean expResult = false;
        boolean result = instance.executionFinished();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of testaVolume method, of class AnimationVia.
     */
    public void testTestaVolume() {
        System.out.println("testaVolume");
        AnimationVia instance = null;
        boolean expResult = false;
        boolean result = instance.testaVolume();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
