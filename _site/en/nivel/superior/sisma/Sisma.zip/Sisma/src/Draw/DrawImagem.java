/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

 /*
 * DrawImagem.java
 *
 * Created on 22/06/2009, 12:02:16
 */
package Draw;

import Core.Mapa;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author Alexandre
 */
public class DrawImagem extends javax.swing.JPanel {

    private Mapa mapa;
    private Image imagem;
    private String caminho;
    private String imgBase64;
    private double posIniX;
    private double posIniY;
    private int largura;
    private int altura;
    private boolean mudandoTamanho;

    /**
     * Creates new form DrawImagem
     *
     * @param path
     * @param mapa
     */
    public DrawImagem(String path, Mapa mapa) {
        initComponents();
        mudandoTamanho = false;
        this.mapa = mapa;
        this.imgBase64 = null;
        this.caminho = path;
        try {
            imagem = getImageWithPath(caminho);
            altura = imagem.getHeight(mapa);
            largura = imagem.getWidth(mapa);
        } catch (IOException ex) {
            Logger.getLogger(DrawImagem.class.getName()).log(Level.SEVERE, caminho, ex);
        }
        repaint();
        setSize((int) largura, (int) altura);
        setLocation(10, 10);
        setVisible(true);
    }

    /**
     *
     * @param imgBase64
     * @param mapa
     */
    public DrawImagem(Mapa mapa, String imgBase64) {
        initComponents();
        mudandoTamanho = false;
        this.mapa = mapa;
        this.imgBase64 = imgBase64;
        this.caminho = null;
        try {
            imagem = getImageWithBase64(imgBase64);
            altura = imagem.getHeight(mapa);
            largura = imagem.getWidth(mapa);
        } catch (IOException ex) {
            Logger.getLogger(DrawImagem.class.getName()).log(Level.SEVERE, null, ex);
        }
        repaint();
        setSize((int) largura, (int) altura);
        setLocation(10, 10);
        setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.drawImage(imagem, 0, 0, null);
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public String getCaminho() {
        return caminho;
    }

    public void setCaminho(String caminho) {
        this.caminho = caminho;
    }

    public Image getImagem() {
        return imagem;
    }

    public void setImagem(Image imagem) {
        this.imagem = imagem;
    }

    public int getLargura() {
        return largura;
    }

    public void setLargura(int largura) {
        this.largura = largura;
    }

    public double getPosIniX() {
        return posIniX;
    }

    public void setPosIniX(double posIniX) {
        this.posIniX = posIniX;
    }

    public double getPosIniY() {
        return posIniY;
    }

    public void setPosIniY(double posIniY) {
        this.posIniY = posIniY;
    }

    public static Image Redimensiona(String caminho, int w, int h) throws IOException {
        BufferedImage fundo = null;
        try {
            fundo = ImageIO.read(new File(caminho));
        } catch (IOException e1) {
            e1.printStackTrace();
            fundo = new BufferedImage(1, 1, BufferedImage.BITMASK);
        }
        return fundo.getScaledInstance(w, h, 10000);
    }

    public Image Redimensiona(int w, int h) throws IOException {
        if (imagem != null) {
            return imagem.getScaledInstance(w, h, 10000);
        } else {
            return null;
        }
    }

    public static Image getImageWithPath(String caminho) throws IOException {
        BufferedImage fundo = null;
        try {
            fundo = ImageIO.read(new File(caminho));
        } catch (IOException e1) {
            e1.printStackTrace();
            fundo = new BufferedImage(1, 1, BufferedImage.BITMASK);
        }
        return fundo;
    }

    public static Image getImageWithBase64(String imgBase64) throws IOException {
        BufferedImage fundo = null;
        try {
            byte[] bytesBase64 = Base64.getDecoder().decode(imgBase64);
            fundo = ImageIO.read(new ByteArrayInputStream(bytesBase64));
        } catch (IOException e1) {
            e1.printStackTrace();
            fundo = new BufferedImage(1, 1, BufferedImage.BITMASK);
        }
        return fundo;
    }

    public String getBase64() throws IOException {
        if (caminho != null) {
            File file = new File(caminho);
            if(!file.exists())
                return null;
            BufferedImage img = ImageIO.read(file);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try {
                ImageIO.write(img, "png", baos);
                baos.flush();
                String encodedImage = Base64.getEncoder().encodeToString(baos.toByteArray());
                return encodedImage;
            } finally {
                baos.close();
            }
        } else {
            return imgBase64;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        jMenuItem1.setText("Delete");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem1);

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createEtchedBorder());
        setComponentPopupMenu(jPopupMenu1);
        setPreferredSize(new java.awt.Dimension(300, 300));
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                formMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                formMouseReleased(evt);
            }
        });
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                formMouseMoved(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 296, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 296, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
        // TODO add your handling code here:

        if (evt.getX() > this.getBounds().getWidth() - 15 && evt.getY() > this.getBounds().getHeight() - 15 || mudandoTamanho) {

            mudandoTamanho = true;

            setBounds(getX(), getY(), evt.getX(), evt.getY());

            try {
                imagem = Redimensiona(getWidth(), getHeight());
                largura = getWidth();
                altura = getHeight();

            } catch (Exception ex) {
                ex.printStackTrace();
            }

        } else {

            Rectangle retangulo = getBounds();
            int iX = evt.getX();
            int iY = evt.getY();

            int totX;
            int totY;
            double totalX = retangulo.getX();
            double totalY = retangulo.getY();

            //Variaveis para colocar o objeto no centro da posição clicada
            int larg, alt;
            larg = retangulo.width;
            alt = retangulo.height;

            totX = (iX + (int) totalX) - (larg / 2);
            totY = (iY + (int) totalY) - (alt / 2);

            setLocation(totX + 30, totY);

            posIniX = totX + 30;
            posIniY = totY;

            repaint();
        }

        updateUI();

    }//GEN-LAST:event_formMouseDragged

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:

        mapa.removeImagem(this);
        setVisible(false);

    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void formMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseMoved
        // TODO add your handling code here:

        if (evt.getX() > this.getBounds().getWidth() - 15 && evt.getY() > this.getBounds().getHeight() - 15) {
            setCursor(new java.awt.Cursor(java.awt.Cursor.SE_RESIZE_CURSOR));
        } else {
            setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        }

    }//GEN-LAST:event_formMouseMoved

    private void formMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseExited
        // TODO add your handling code here:

        mudandoTamanho = false;

    }//GEN-LAST:event_formMouseExited

    private void formMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseReleased
        // TODO add your handling code here:

        mudandoTamanho = false;

    }//GEN-LAST:event_formMouseReleased

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPopupMenu jPopupMenu1;
    // End of variables declaration//GEN-END:variables
}
