/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Draw;

import java.awt.*;
import java.awt.geom.*;
import static java.lang.Math.*;

public class DrawArrow2D {

    private QuadCurve2D quadCurve;
    private Line2D.Double line;

    //Point p1,p2,p3,pTemp;
    //int count=0;
    public DrawArrow2D() {

        quadCurve = new QuadCurve2D.Float();
        line = new Line2D.Double();

    }

    public void drawArrow(Graphics2D g2D, double p1X, double p1Y, double ctrlPX, double ctrlPY, double p2X, double p2Y) {
        if (ctrlPX == p2X && ctrlPY == p2Y) {
            line.setLine(p1X, p1Y, p2X, p2Y);
            g2D.draw(line);
            drawTipArrow(g2D, (int) line.getX1(), (int) line.getY1(), (int) line.getX2(), (int) line.getY2());

        } else {
            quadCurve.setCurve(p1X, p1Y, ctrlPX, ctrlPY, p2X, p2Y);
            g2D.draw(quadCurve);
            drawTipArrow(g2D, (int) (quadCurve.getCtrlPt().getX()), (int) (quadCurve.getCtrlPt().getY()), (int) (quadCurve.getP2().getX()), (int) (quadCurve.getP2().getY()));
        }

    }

    public void drawLineArrow(Graphics2D g2D, double p1X, double p1Y, double p2X, double p2Y) {

        line.setLine(p1X, p1Y, p2X, p2Y);
        g2D.draw(line);
        drawTipArrow(g2D, (int) line.getX1(), (int) line.getY1(), (int) line.getX2(), (int) line.getY2());

    }

    public void drawCurveArrow(Graphics2D g2D) {

//      if(p1 != null && p2 == null && count == 1 ){
//          g2D.drawLine(p1.x, p1.y, pTemp.x, pTemp.y);
//      }
//      if(p1 != null && p2 != null){
//          g2D.drawLine(p1.x, p1.y, p2.x, p2.y);
//      }
//      if(p2 != null && count == 2 ){
//          g2D.drawLine(p2.x, p2.y, pTemp.x, pTemp.y);
//      }
        g2D.draw(quadCurve);
        drawTipArrow(g2D, (int) (quadCurve.getCtrlPt().getX()), (int) (quadCurve.getCtrlPt().getY()), (int) (quadCurve.getP2().getX()), (int) (quadCurve.getP2().getY()));

    }

//    public void mousePressed(java.awt.event.MouseEvent e) {
//        if(count == 0){
//            p1 = e.getPoint();
//            count++;
//        }else if(count == 1){
//            p2 = e.getPoint();
//            count++;
//        }else if(count == 2){
//            p3 = e.getPoint();
//            count = 0;
//            quadCurves.add(new QuadCurve2D.Float(p1.x,p1.y,p2.x,p2.y,p3.x,p3.y));
//            repaint();
//            p1 = p2 = p3 = null;
//
//        }
    public static void drawTipArrow(Graphics2D g, int xi, int yi, int xf, int yf) {

        Line2D.Double tip = new Line2D.Double();

        double alfa = (atan2((yf - yi), (xf - xi)));
        double length = sqrt(pow((xf - xi), 2) + pow((yf - yi), 2));
        if (length < 0) {
            alfa += PI;
            length *= -1;
        }

        double xf2;
        double yf2;

        xf2 = xi + length * Math.cos(alfa);
        yf2 = yi + length * Math.sin(alfa);

        drawTip(g, xf2, yf2, alfa + (3 * PI / 2.0) - (PI / 3), tip, 10);
        drawTip(g, xf2, yf2, alfa + (PI / 2.0) + (PI / 3), tip, 10);
    }

    protected static void drawTip(Graphics2D g,
            double x1, double y1,
            double beta, Line2D.Double tip, double tip_length) {
        double x2;
        double y2;

        x2 = x1 + tip_length * Math.cos(beta);
        y2 = y1 + tip_length * Math.sin(beta);

        tip.setLine(x1, y1, x2, y2);

        g.draw(tip);
    }

}
