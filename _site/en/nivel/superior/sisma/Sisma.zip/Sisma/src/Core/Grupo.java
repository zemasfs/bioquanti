package Core;

/*
 * Grupo.java
 *
 * Created on 15 de Janeiro de 2008, 16:56
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
import java.awt.Color;
import java.io.Serializable;

/**
 * O objetivo dessa classe é criar grupos para os compostos, cada grupo é
 * representado por uma cor e existem grupos pre estabelecidos com suas cores ja
 * definidas que podem ser criados.
 *
 * @author José Alexandre Macedo
 * @author Neubio Matos Ferreira
 */
public class Grupo implements Serializable {

    private String nome;
    private Color cor;
    private float[] hsb;

    /**
     * Constuir um grupo que tenha como parametro o seu nome
     *
     * @param nome - com o qual o grupo ser construdo
     */
    public Grupo(String nome) {
        //this.nome = "Black";
        //Os compostos Lipdeos tero a cor azul por definio
        if (nome.equals("Black")) {
            this.nome = "Black";
            hsb = Color.RGBtoHSB(1, 1, 1, null);//parametros de cores
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }
        if (nome.equals("Purple")) {
            this.nome = "Purple";
            hsb = Color.RGBtoHSB(255, 0, 255, null);//parametros de cores
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }
        if (nome.equals("Yellow")) {
            this.nome = "Yellow";
            hsb = Color.RGBtoHSB(255, 255, 0, null);//parametros de cores
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }
        //Os compostos Lipdeos tero a cor azul por definio
        if (nome.equals("Blue")) {
            this.nome = "Blue";
            hsb = Color.RGBtoHSB(0, 0, 255, null);//parametros de cores
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }
        //Os compostos Aminocidos tero a cor vermelha por definio
        if (nome.equals("Red")) {
            this.nome = "Red";
            hsb = Color.RGBtoHSB(255, 0, 0, null);
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }

        //Os compostos Carboidratos tero a cor verde por definio
        if (nome.equals("Green")) {
            this.nome = "Green";
            hsb = Color.RGBtoHSB(0, 255, 0, null);
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }

        //Os compostos Bases de cido nuclico tero a cor laranja por definio
        if (nome.equals("Orange")) {
            this.nome = "Orange";
            hsb = Color.RGBtoHSB(255, 213, 0, null);
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }

    }

    /**
     * Mtodo que mostra a cor do grupo
     *
     * @return a cor correspondente ao nome do grupo
     */
    public Color getCor() {
        return cor;
    }

    /**
     * Mtodo que modifica a cor de acordo com um volume x que varia de 0 a 100
     *
     * @param volume - volume ao qual a cor est relacionada, quanto maior este
     * volume maior o brilho de uma cor.
     */
    public void setCor(double volume) {
        int brilho = 0;
        //int intensidade=80;
        int brilho1 = 0;
        //int intensidade1=48;

        /*Formula na qual mostra a mudana no brilho de acordo com a 
        quantidade de volume:  brilho=((int)(255*(100-volume)/100));*/
 /*Formula na qual mostra a mudana na intensidade das cores de acordo
         com a quantidade de volume.*/
        //intensidade=(int)((175*volume+8000)/100);
        brilho = ((int) (255 * (100 - volume) / 100));

        /*Para calcular a intensidade da cor laranja  necessario fazer um
         outro calculo pois a variao da cor laranja varia dois parametros do 
         RGBD , enquanto que outras variam apenas um parametro.*/
        if (nome.equals("Orange")) {
            brilho1 = ((int) (255 - (102 * volume) / 100));
        }
        //intensidade1=(int)((105*volume+13300)/100); 

        /*Converso necessria pois a tabela RGB vai de 0(cor mais forte)
        ate 255 (branco) para ficar equivalente ao volume(conforme o volume
        aumenta a cor fica forte conforme o volume diminui o brilho diminui
         necessrio fazer esta converso */
        if (nome.equals("Black")) {
            hsb = Color.RGBtoHSB(brilho, brilho, brilho, null);
            //hsb=Color.RGBtoHSB(0, 0, intensidade, null);
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }
        if (nome.equals("Purple")) {
            hsb = Color.RGBtoHSB(255, brilho, 255, null);//parametros de cores
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }
        if (nome.equals("Yellow")) {
            hsb = Color.RGBtoHSB(255, 255, brilho, null);//parametros de cores
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }
        if (nome.equals("Blue")) {
            hsb = Color.RGBtoHSB(brilho, brilho, 255, null);
            //hsb=Color.RGBtoHSB(0, 0, intensidade, null);
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }
        if (nome.equals("Red")) {
            hsb = Color.RGBtoHSB(255, brilho, brilho, null);
            //hsb=Color.RGBtoHSB(intensidade, 0, 0, null);
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }
        if (nome.equals("Green")) {
            hsb = Color.RGBtoHSB(brilho, 255, brilho, null);
            //hsb=Color.RGBtoHSB(0, intensidade, 0, null);
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }
        if (nome.equals("Orange")) {
            hsb = Color.RGBtoHSB(255, brilho1, brilho, null);
            //hsb= Color.RGBtoHSB(intensidade, intensidade1, 0, null);
            cor = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
        }
    }

    /**
     * Metodo que mostra o nome do grupo
     *
     * @return o nome do grupo
     */
    public String getNome() {
        return this.nome;
    }

    public void setName(String nome) {
        if (nome.equals("Black") || nome.equals("Purple") || nome.equals("Yellow")
                || nome.equals("Blue") || nome.equals("Red") || nome.equals("Green")
                || nome.equals("Orange")) {
            this.nome = nome;
        }
    }
}
