package Core;

/*
 * Composto.java
 *
 * Created on 15 de Janeiro de 2008, 16:54
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
import Draw.DrawConector;
import Draw.DrawComposto;
import java.awt.Color;
import java.io.Serializable;
import org.jfree.data.xy.XYDataItem;
import org.jfree.data.xy.XYSeries;

/**
 * O objetivo dessa classe é criar e possibilitar a manipulação de um composto.
 *
 * @author José Alexandre Macedo
 * @author Neubio Matos Ferreira
 */
public class Composto implements Serializable {

    private Mapa mapa;
    private Grupo grupoCor;
    private String nome;
    private int id;
    private double volume;
    private int posX;
    private int posY;
    private DrawComposto desenho;
    private boolean plot, init;
    private XYSeries series;

    /**
     * Construir um composto sem nenhuma informação vinculada a ele.
     */
    public Composto(Mapa mapa, int posX, int posY) {
        this(mapa, "Black", "Object", 100, 0, 0);
        this.posX = posX;
        this.posY = posY;
        this.plot = true;
        this.series = new XYSeries("Object");
        this.desenho = new DrawComposto(this, mapa);
        desenho.setBounds(posX, posY, 130, 40);
        if (mapa.getCompostos().size() == 0) {
            this.id = 1;
        } else {
            this.id = mapa.getCompostos().get(mapa.getCompostos().size() - 1).getId() + 1;
        }
    }

    /**
     * Construir um composto que possue as seguintes informa��ens:Mapa na qual
     * pertence grupo que esta vinculado, o seu nome e a quantidade de volume
     * que ele possui.
     *
     * @param mapa - Indica o mapa no qual o composto ira pertencer
     * @param grupo - Indica o grupo no qual o composto ira pertencer (define
     * sua cor)
     * @param nome - Indica o nome do composto
     * @param volume - Indica o volume inicial do composto
     */
    public Composto(Mapa mapa, String grupo, String nome, double volume) {
        grupoCor = new Grupo(grupo);
        this.nome = nome;
        this.mapa = mapa;
        this.volume = volume;
        grupoCor.setCor(volume);
        this.posX = 0;
        this.posY = 0;
        this.plot = true;
        this.series = new XYSeries(this.nome);
        this.desenho = new DrawComposto(this, mapa);
        if (mapa.getCompostos().size() == 0) {
            this.id = 1;
        } else {
            this.id = mapa.getCompostos().get(mapa.getCompostos().size() - 1).getId() + 1;
        }

    }

    /**
     * Construir um composto que possue as seguintes informa��ens: Grupo no qual
     * pertence, o seu nome e a quantidade de volume que ele possui.
     *
     * @param mapa - Indica o mapa no qual o composto ira pertencer
     * @param grupo - Indica o grupo no qual o composto ira pertencer (define
     * sua cor)
     * @param nome - Indica o nome do composto
     * @param volume - Indica o volume inicial do composto
     * @param posX - Indica a posi��o inicial do composto no eixo x
     * @param posY - Indica a posi��o inicial do composto no eixo y
     */
    public Composto(Mapa mapa, String grupo, String nome, double volume, int posX, int posY) {
        grupoCor = new Grupo(grupo);
        this.nome = nome;
        this.mapa = mapa;
        this.volume = volume;
        grupoCor.setCor(volume);
        this.posX = posX;
        this.posY = posY;
        this.plot = true;
        this.series = new XYSeries(this.nome);
        this.desenho = new DrawComposto(this, mapa);
        desenho.setBounds(posX, posY, 130, 40);
        if (mapa.getCompostos().size() == 0) {
            this.id = 1;
        } else {
            this.id = mapa.getCompostos().get(mapa.getCompostos().size() - 1).getId() + 1;
        }
    }

    /**
     * M�todo para alterar o nome do composto.
     *
     * @param nome - Novo nome do composto
     */
    public void setNome(String nome) {
        this.nome = nome;
        this.desenho.setNome(nome);

        XYDataItem[] it = new XYDataItem[series.getItemCount()];
        for (int i = 0; i < series.getItemCount(); i++) {
            it[i] = series.getDataItem(i);
        }
        this.series = new XYSeries(this.nome);
        for (XYDataItem item : it) {
            series.add(item);
        }
    }

    /**
     * Metodo para alterar o grupo do composto.
     *
     * @param grupo - Novo grupo do composto
     */
    public void setGrupo(String grupo) {
        this.grupoCor.setName(grupo);
    }

    /**
     * Metodo para alterar a posi��o do composto.
     *
     * @param posX - Altera a posi��o do composto no eixo X
     * @param posY - Altera a posi��o do composto no eixo Y
     */
    public void setPosXY(int posX, int posY) {
        this.posX = posX;
        this.posY = posY;
        desenho.setBounds(posX, posY, 130, 40);
    }

    /**
     * Metodo para alterar o volume do composto onde o seu valor deve ser maior
     * que zero ou menor que 100.Caso o volume do composto n�o esteja nesse
     * intervalo aparecer� uma mensagem de erro conforme escrita abaixo.
     *
     * @param volume - Altera o volume do composto
     */
    public void setVolume(double volume) {
        synchronized (this) {
            if (volume < 0 && volume > 100) {
                throw new IllegalArgumentException("N�o existem volumes negativos e volumes acima de 100");
            } else {
                this.volume = volume;
                grupoCor.setCor(volume);
            }
        }
    }

    /**
     * M�todo na qual eu apresento o nome do composto.
     *
     * @return nome do composto
     */
    public String getNome() {
        return nome;
    }

    /**
     * M�todo na qual eu apresento o grupo na qual o composto est� vinculado.
     *
     * @return nome do grupo do composto
     */
    public String getGrupo() {
        return grupoCor.getNome();
    }

    /**
     * M�todo na qual eu apresento a cor do composto.
     *
     * @return cor do grupo do composto
     */
    public Color getCor() {
        return grupoCor.getCor();
    }

    /**
     * M�todo na qual eu apresento o volume do composto.
     *
     * @return volume do composto
     */
    public double getVolume() {
        return volume;
    }

    /**
     * M�todo na qual eu apresento a posi��o no eixo X do composto.
     *
     * @return posi��o no eixo X do composto
     */
    public int MostraPosX() {
        return this.posX;
    }

    /**
     * M�todo na qual eu apresento a posi��o no eixo Y do composto.
     *
     * @return posi��o no eixo Y do composto
     */
    public int MostraPosY() {
        return this.posY;
    }

    /**
     * M�todo na qual eu adiciono um volume a um composto.
     *
     * @param vol - Valor a ser adicionado ao composto
     */
    public void AddVolume(double vol) {

        volume += vol;
        if (volume > 100) {
            volume = 100;
        }
        grupoCor.setCor(volume);
    }

    /**
     * M�todo na qual eu retiro um volume de um composto.
     *
     * @param vol - Valor a ser retirado do composto
     */
    public void RemoveVolume(double vol) {
        if (volume - vol >= 0) {
            volume -= vol;
            grupoCor.setCor(volume);
        }
    }

    /**
     * M�todo que verifica se o volume do composto � igual a zero, ou seja se
     * ele est� vazio.
     */
    public boolean EstaVazio() {
        if (volume <= 1.0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * M�todo que verifica se o composto est� com o seu volume maximo, ou seja
     * se ele est� cheio.
     */
    public boolean EstaCheio() {
        if (volume >= 100) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Informa��ens sobre os objetos criados na classe
     *
     * @return as informa��es do composto
     */
    @Override
    public String toString() {
        return "|------------------------------------------------|\n"
                + " Composto: " + nome + " do Grupo: " + getGrupo() + "\n"
                + " Volume:" + volume + "\n"
                + " Numero de Vias: 12\n"
                + "|------------------------------------------------|\n";
    }

    /**
     * M�todo que mostra o desenho do composto
     *
     * @return desenho do composto
     */
    public DrawComposto getDesenhoComposto() {
        return desenho;
    }

    /**
     * M�todo no qual mostra o mapa no qual o composto pertence
     *
     * @return mapa no qual o composto pertence
     */
    public Mapa getMapaComposto() {
        return this.mapa;
    }

    public void setPlot(boolean isplot) {
        this.plot = isplot;
    }

    public boolean getPlot() {
        return this.plot;
    }

    public void addSeries(double temp, double volume) {
        this.series.add(temp, volume);
    }

    public XYSeries getSerie() {
        return this.series;
    }

    public void ClearSerie() {
        this.series.clear();
    }

    public synchronized void startAnimationComposto(int tempo) {
        for (DrawConector conector : getDesenhoComposto().getConectores()) {
            if (conector.existeVia() && conector.getVia().getCompoundA() == this) {
                conector.getVia().getAnimationExecution().execute(tempo);
            }
        }
    }

    public boolean isInit() {
        return init;
    }

    public void setInit(boolean init) {
        this.init = init;
        if (init && !mapa.getCompostosIniciais().contains(this)) {
            mapa.getCompInicial().add(this);
        } else if (!init && mapa.getCompostosIniciais().contains(this)) {
            mapa.getCompInicial().remove(this);
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
