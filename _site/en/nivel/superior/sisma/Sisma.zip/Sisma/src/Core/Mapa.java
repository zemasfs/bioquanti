package Core;

/*
 * Mapa.java
 *
 * Created on 15 de Janeiro de 2008, 18:45
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
import Draw.*;
import Interfaces.JTabbedPaneWithCloseIcons;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Point;
import javax.swing.JPopupMenu;

/**
 *
 * O Objetivo desta classe é possibilitar a criação e manipulação de mapas com
 * vários compostos e vias
 *
 * @author José Alexandre Macedo
 * @author Neubio Matos Ferreira
 */
public class Mapa extends JPanel
        implements Serializable, MouseListener, MouseMotionListener {

    public JLabel name;
    public ArrayList<Composto> Compostos;
    public ArrayList<Via> Vias;
    public ArrayList<DrawAreaTexto> AreasDeTexto;
    public ArrayList<DrawImagem> Imagens;
    public ArrayList<String> Equacoes;
    public ArrayList<Composto> compInicial;
    public JMenuItem createElement;
    public JMenuItem createWay;
    public JMenuItem createNote;
    public JMenuItem renameMap;
    public JPopupMenu menu;
    public JTabbedPaneWithCloseIcons tabPanel;
    public int indexTab;
    public static Point p1, p2, p3, pTemp;
    public static int count = 0;
    public static DrawArrow2D arrow;
    public static boolean AptoParaCriarComposto;
    public static boolean AptoParaCriarVia;
    public static boolean AptoParaCriarAreaTexto;
    public static boolean ArrastoInicial;
    public static DrawConector conectorIniTemp, conectorFimTemp;
    public String pathWorkingMap;

    public Mapa(Mapa m) {
        this.name = m.name;
        this.Compostos = m.Compostos;
        this.Vias = m.Vias;
        this.AreasDeTexto = m.AreasDeTexto;
        this.Imagens = m.Imagens;
        this.Equacoes = m.Equacoes;
        this.compInicial = m.compInicial;
        this.createElement = m.createElement;
        this.createWay = m.createWay;
        this.createNote = m.createNote;
        this.renameMap = m.renameMap;
        this.menu = m.menu;
        this.tabPanel = m.tabPanel;
        this.indexTab = m.indexTab;
        this.pathWorkingMap = m.pathWorkingMap;
    }

    /**
     * Cria um mapa com suas caracter�sticas
     */
    public Mapa() {
        name = new JLabel("New Map");

        name.setBounds(5, 0, 600, 50);
        name.setFont(new Font("Bitstream Vera Serif", Font.BOLD, 18));
        add(name);
        setSize(890, 730);
        setLayout(null);
        setBackground(Color.WHITE);

        arrow = new DrawArrow2D();
        AptoParaCriarComposto = false;
        AptoParaCriarVia = false;
        AptoParaCriarAreaTexto = false;
        ArrastoInicial = true;
        conectorIniTemp = null;
        conectorFimTemp = null;
        tabPanel = null;
        indexTab = -1;

        createElement = new JMenuItem("Object");
        createWay = new JMenuItem("Path");
        createNote = new JMenuItem("Note");
        renameMap = new JMenuItem("Rename");

        createEventosPopUpMenu();

        menu = new JPopupMenu("Menu");
        menu.add(createElement);
        menu.add(createWay);
        menu.add(createNote);
        menu.addSeparator();
        menu.add(renameMap);
        setComponentPopupMenu(menu);

        compInicial = null;

        Compostos = new ArrayList<Composto>();
        compInicial = new ArrayList<Composto>();
        Vias = new ArrayList<Via>();
        Equacoes = new ArrayList<String>();
        AreasDeTexto = new ArrayList<DrawAreaTexto>();
        Imagens = new ArrayList<DrawImagem>();
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    public Mapa(String nome) {
        name = new JLabel(nome);

        name.setBounds(5, 0, 600, 50);
        name.setFont(new Font("Bitstream Vera Serif", Font.BOLD, 18));
        add(name);
        setSize(890, 730);
        setLayout(null);
        setBackground(Color.WHITE);

        /*Inicio variaveis usadas para cria��o de uma nova via*/
        arrow = new DrawArrow2D();
        AptoParaCriarComposto = false;
        AptoParaCriarVia = false;
        AptoParaCriarAreaTexto = false;
        ArrastoInicial = true;
        conectorIniTemp = null;
        conectorFimTemp = null;
        tabPanel = null;
        indexTab = -1;
        /*Fim variaveis usadas para cria��o de uma nova via*/

        createElement = new JMenuItem("Object");
        createWay = new JMenuItem("Path");
        createNote = new JMenuItem("Note");
        renameMap = new JMenuItem("Rename");

        createEventosPopUpMenu();

        menu = new JPopupMenu("Menu");
        menu.add(createElement);
        menu.add(createWay);
        menu.add(createNote);
        menu.addSeparator();
        menu.add(renameMap);
        setComponentPopupMenu(menu);

        compInicial = null;

        Compostos = new ArrayList<Composto>();
        compInicial = new ArrayList<Composto>();
        Vias = new ArrayList<Via>();
        Equacoes = new ArrayList<String>();
        AreasDeTexto = new ArrayList<DrawAreaTexto>();
        Imagens = new ArrayList<DrawImagem>();
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    /**
     * Método que adiciona um composto ao mapa
     *
     * @param x - composto que será adicionado ao mapa
     */
    public void addComposto(Composto x) {
        Compostos.add(x);
        if (Compostos.size() == 1) {
            getCompInicial().add(Compostos.get(0));
            Compostos.get(0).setInit(true);
        }
    }

    public ArrayList<DrawAreaTexto> getAreasDeTexto() {
        return AreasDeTexto;
    }

    public void setTabEIndex(JTabbedPaneWithCloseIcons tab, int index) {
        this.tabPanel = tab;
        this.indexTab = index;
    }

    public void setIndexTab(int index) {
        this.indexTab = index;
    }

    public void addAreaText(DrawAreaTexto area) {
        AreasDeTexto.add(area);
    }

    public void addImagemMapa(DrawImagem imagem) {
        Imagens.add(imagem);
        this.add(imagem, -1);
        this.updateUI();
    }

    public void createEventosPopUpMenu() {
        createElement.addActionListener((java.awt.event.ActionEvent evt) -> {
            AptoParaCriarComposto = true;
        });

        createWay.addActionListener((java.awt.event.ActionEvent evt) -> {
            AptoParaCriarVia = true;
        });

        createNote.addActionListener((java.awt.event.ActionEvent evt) -> {
            AptoParaCriarAreaTexto = true;
        });

        renameMap.addActionListener((java.awt.event.ActionEvent evt) -> {
            String input = JOptionPane.showInputDialog(null, "New name:");
            if (input == null || input.equals("")) {
                return;
            }
            name.setText(input);
            if (tabPanel != null && indexTab >= 0) {
                tabPanel.setTitleAt(indexTab, input);
            }
        });
    }

    /**
     * Método que adiciona uma via ao mapa
     *
     * @param x - via que será adicionada ao mapa
     */
    public void addVia(Via x) {
        Vias.add(x);
    }

    /**
     * Método que remove um composto do mapa
     *
     * @param compostoRemovido - composto que será removido do mapa
     */
    public void removeComposto(Composto compostoRemovido) {
        if (Compostos.size() != 1) {
            if (Compostos.indexOf(compostoRemovido) == 0 && Compostos.size() >= 0) {
                getCompInicial().add(Compostos.get(1));
            }
        }
        Compostos.remove(compostoRemovido);
        if (getCompInicial().contains(compostoRemovido)) {
            getCompInicial().remove(compostoRemovido);
        }
        remove(compostoRemovido.getDesenhoComposto());
        for (DrawConector k : compostoRemovido.getDesenhoComposto().getConectores()) {
            remove(k);
        }
        repaint();
        CriarMapa();
    }

    /**
     * Método que remove uma via do mapa
     *
     * @param viaRemovida - via que será removida do mapa
     */
    public void removeVia(Via viaRemovida) {
        Vias.remove(viaRemovida);
    }

    public void removeImagem(DrawImagem imagemRemovida) {
        Imagens.remove(imagemRemovida);
    }

    /**
     * Método que retorna todas as vias de um certo composto
     *
     * @param x - composto do qual serão pegas as vias
     */
    public void removeViasDoComposto(Composto x) {
        for (Via y : Vias) {
            if (x == (y.getCompoundA()) || x == (y.getCompoundB())) {
                removeVia(y);
            }
        }
        repaint();
    }

    /**
     * Método que desenha as vias no mapa
     *
     * @param g - local onde serão desenhadas as vias
     */
    public void paint(Graphics g) {
        super.paint(g);
        for (Via x : Vias) {
            x.DrawVia(g);
        }

        //if(AptoParaCriarVia && !ArrastoInicial){
        g.setColor(Color.BLACK);
        if (p1 != null && p2 == null && count == 1) {
            g.drawLine(p1.x, p1.y, pTemp.x, pTemp.y);
        }
        if (p1 != null && p2 != null) {
            g.drawLine(p1.x, p1.y, p2.x, p2.y);
        }
        if (p2 != null && count == 2) {
            g.drawLine(p2.x, p2.y, pTemp.x, pTemp.y);
        }
        //arrow.drawArrow((Graphics2D) g, posIniX,posIniY,p2.getX(),p2.getY(),posFimX,posFimY);
        //}
    }

    /**
     * Método que cria um mapa adicionando todos os compostos com seus
     * conectores no JPanel do mapa
     */
    public void CriarMapa() {
        if (!Compostos.isEmpty()) {
            for (Composto x : Compostos) {
                add(x.getDesenhoComposto(), 0);
                for (DrawConector k : x.getDesenhoComposto().getConectores()) {
                    add(k, 0);
                }
                x.getDesenhoComposto().setBounds(x.MostraPosX(), x.MostraPosY(), 200, 50);
            }
        }
        if (!AreasDeTexto.isEmpty()) {
            for (DrawAreaTexto area : AreasDeTexto) {
                add(area, 0);
            }
        }
    }

    /**
     * M�todo que atualiza a cor dos compostos do mapa e redesenha as vias
     */
    public void AtualizaMapa() {
        if (!Compostos.isEmpty()) {
            for (Composto x : Compostos) {
                x.getDesenhoComposto().setCorComposto();
            }
        }
        repaint();
    }

    /**
     * M�todo que atualiza a posi��o dos compostos e das vias do mapa e
     * redesenha as vias
     */
    public void AtualizaPos() {
        if (!Compostos.isEmpty()) {
            for (Composto x : Compostos) {
                x.getDesenhoComposto().setBounds(x.MostraPosX(), x.MostraPosY(), 200, 50);
            }
        }
        for (Via y : Vias) {
            y.AtualizaPosVia();
        }
        repaint();

    }

    /**
     * M�todo que mostra as vias do mapa
     *
     * @return todas as vias do mapa em um ArrayList
     */
    public ArrayList<Via> getVias() {
        return Vias;
    }

    public ArrayList<Composto> getCompostos() {
        return Compostos;
    }

    public ArrayList<Composto> getCompostosIniciais() {
        return getCompInicial();
    }

    public int NumVias() {
        return Vias.size();
    }

    // public void setCompInicial(Composto x){
    //     this.compInicial=x;
    //}
    public boolean existeViaSimulando() {
        for (Via y : Vias) {
            if (y.getSimulando()) {
                return true;
            }
        }
        return false;
    }

    public void atualizaAreaTexto() {
        for (DrawAreaTexto area : AreasDeTexto) {
            area.createEventosPopUpMenu();
        }
    }

    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON3 && AptoParaCriarVia) {
            ArrastoInicial = true;
            conectorIniTemp = null;
            conectorFimTemp = null;
            AptoParaCriarVia = false;
            //removeViaConect();

            repaint();
        }

        if (count == 1) {
            p2 = e.getPoint();
            count++;
        }

        if (AptoParaCriarComposto) {
            Composto compTemp = new Composto(this, e.getX(), e.getY());
            addComposto(compTemp);
            CriarMapa();
            AtualizaMapa();
            AptoParaCriarComposto = false;
            compTemp.getDesenhoComposto().mouseClicked(null);
        }
        if (AptoParaCriarAreaTexto) {
            DrawAreaTexto areaTexto = new DrawAreaTexto(this, e.getX(), e.getY());
            add(areaTexto);
            AreasDeTexto.add(areaTexto);
            areaTexto.setVisible(true);
            areaTexto.ganhaFoco();
            setVisible(true);
            AtualizaMapa();
            AptoParaCriarAreaTexto = false;
        }
    }

    public void removeTextArea(DrawAreaTexto x) {
        AreasDeTexto.remove(x);
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
    }

    public void mouseMoved(MouseEvent e) {
        pTemp = e.getPoint();
        if (AptoParaCriarVia && !ArrastoInicial) {
            //p3 = new Point(e.getX(), e.getY());
            repaint();
        }
        if (conectorIniTemp != null && conectorFimTemp != null) {
            Via viaTemp = new Via(conectorIniTemp, p2.getX(), p2.getY(), conectorFimTemp);
            addVia(viaTemp);
            AtualizaMapa();
            //viaTemp.mousePressed(event);
            conectorIniTemp = null;
            conectorFimTemp = null;
            p1 = p2 = p3 = null;
            viaTemp.getCntA().mouseClicked(null);
        }
    }

    public String getNome() {
        return name.getText();
    }

    public String toString() {
        String retorno = "";
        for (Composto comp : Compostos) {
            retorno += comp;
        }
        for (Via viaAux : Vias) {
            retorno += viaAux;
        }

        return retorno;
    }

    public ArrayList<DrawImagem> getImagens() {
        return Imagens;
    }

    public ArrayList<Composto> getCompInicial() {
        return compInicial;
    }

    /**
     * @return the pathWorkingMap
     */
    public String getPathWorkingMap() {
        return pathWorkingMap;
    }

    /**
     * @param pathWorkingMap the pathWorkingMap to set
     */
    public void setPathWorkingMap(String pathWorkingMap) {
        this.pathWorkingMap = pathWorkingMap;
    }
}
