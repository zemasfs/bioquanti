package Equacao;

import java.io.Serializable;

/*
 * Variable.java
 *
 * Created on 26 de Março de 2008, 15:02
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author Theodoro
 */
public class Variable implements Serializable {

    private char nome;
    private String fantasyName;
    private double valor;

    /**
     * Creates a new instance of Variable
     */
    public Variable(char nome) {
        this.nome = nome;
        valor = 0;
    }

    public Variable(char nome, String fantasyName) {
        this.nome = nome;
        this.fantasyName = fantasyName;
        valor = 50;
    }

    public Variable(char nome, Double valor) {
        this.nome = nome;
        this.fantasyName = null;
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public char getNome() {
        return nome;
    }

    public void setNome(char nome) {
        this.nome = nome;
    }

    public String getFantasyName() {
        return fantasyName;
    }

    public void setFantasyName(String fantasyName) {
        this.fantasyName = fantasyName;
    }

}
