/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Core;

import Draw.DrawConector;
import Interfaces.PainelSimulacoes;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Nicolas Bontempo
 */
public class AnimationVia {

    private Via via;
    private Mapa mapa;
    private int tempo;
    private static int[] velocidade = {0, 3000, 2000, 1000, 750, 500, 250};
    private ArrayList<Double> volumeAnterior;

    public AnimationVia(Mapa mapa, Via y, int veloc) {
        this.via = y;
        this.mapa = mapa;
        tempo = 1;
        volumeAnterior = new ArrayList<>();
        for (int i = 0; i < this.mapa.getCompostos().size(); i++) {
            volumeAnterior.add(Double.MAX_VALUE);
        }
    }

    public int execute(int tempo) {
        this.tempo = tempo;
        try {
            via.setSimulando(true);

            if (!via.getCompoundA().EstaVazio() && via.getInterferencia().getQuantidade() > 0
                    && via.CalculaTaxaFinal() != 0) {
                System.out.println("taxa atual: " + via.CalculaTaxaFinal());
                via.AplicaTranferencia();
                mapa.AtualizaMapa();

                volumeAnterior.removeAll(volumeAnterior);
                for (Composto x : mapa.getCompostos()) {
                    x.addSeries(tempo, x.getVolume());
                    volumeAnterior.add(x.getVolume());
                }
                tempo++;
                Thread.sleep(velocidade[via.getInterferencia().getQuantidade()]);
            }

            via.setSimulando(false);
        } catch (InterruptedException ex) {
            Logger.getLogger(PainelSimulacoes.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tempo;
    }
    public boolean executionFinished(){
        return !(!via.getCompoundA().EstaVazio() && via.getInterferencia().getQuantidade() > 0
                    && via.CalculaTaxaFinal() != 0);
    }
    public boolean testaVolume() {
        for (int i = 0; i < mapa.getCompostos().size(); i++) {
            if (mapa.getCompostos().get(i).getVolume() != volumeAnterior.get(i)) {
                return false;
            }
        }
        return true;
    }
}
