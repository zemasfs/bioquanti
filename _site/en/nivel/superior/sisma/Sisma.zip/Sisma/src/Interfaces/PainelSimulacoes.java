package Interfaces;


/*
 * PainelSimulacoes.java
 *
 * Created on 21 de Janeiro de 2008, 17:55
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
import Core.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.data.xy.XYSeriesCollection;

/**
 *
 * @author José Alexandre Macedo
 * @author Neubio Matos Ferreira
 */
public class PainelSimulacoes {

    private Mapa mapa;
    private Mapa mapaAux;

    final int[] velocidade = {3000, 2000, 1000, 500, 250};
    public static int veloc;
    private String relatorio;
    private Thread threadExecution;
    private final XYSeriesCollection dataset;
    //se estiver sendo feita uma simulacao os compostos nao podem mudar de posicao
    public static boolean AptoParaSimulacao;
    private boolean pausado;
    //private ArrayList<Via> viasSimulando = new ArrayList<Via>();

    /**
     * Creates a new instance of PainelSimulacoes
     */
    public PainelSimulacoes() {
        PainelSimulacoes.veloc = 0;

        this.threadExecution = null;
        dataset = new XYSeriesCollection();
        AptoParaSimulacao = false;
        pausado = false;
    }

    public void SetVelocidade(int i) {
        veloc = velocidade[i - 1];
    }

    public boolean ExisteMapa() {
        return mapa != null;
    }

    public boolean ExisteRelatorio() {
        return relatorio != null;
    }

    public void removeMapa() {
        if (ExisteMapa()) {
            //remove(mapa);
            //relatorio=null;
            mapa = null;
        }
    }

    public void setMapa(Mapa map) {
        mapa = map;
    }

    public void setMapaAux(Mapa map) {
        mapaAux = new Mapa(map);
    }

    public Mapa getMapa() {
        return mapa;
    }

    public Mapa getMapaAux() {
        return mapaAux;
    }

    public void startAnimation() {
        if (threadExecution != null) {
            if (pausado) {
                threadExecution.resume();
                pausado = false;
                AptoParaSimulacao = true;
                SISMAControle.mensagemJLabel.setText("Simulating...");
            }
        } else if (ExisteMapa() && !AptoParaSimulacao) {
            for (Composto x : mapa.getCompostos()) {
                x.ClearSerie();
                x.addSeries(0, x.getVolume());
            }
            AptoParaSimulacao = true;

            QueueControlMod queueOfExecution = new QueueControlMod(mapa, this);
            for (Composto x : mapa.getCompInicial()) {
                queueOfExecution.addFirstCompound(x);
            }
            threadExecution = new Thread(queueOfExecution);
            threadExecution.start();

            pausado = false;

            SISMAControle.mensagemJLabel.setText("Simulating...");
        }
    }

    public void finishAnimation() {
        AptoParaSimulacao = false;
        pausado = true;
        SISMAControle.mensagemJLabel.setText("Finished !");
    }

    public synchronized void pauseAnimation() throws InterruptedException {
        if (ExisteMapa()) {
            if (threadExecution != null && threadExecution.isAlive()) {
                threadExecution.suspend();
                AptoParaSimulacao = false;
                pausado = true;
            }
            SISMAControle.mensagemJLabel.setText("Paused !");
        }
    }

    public void restartAnimation() {
        if (ExisteMapa()) {
            try {
                pauseAnimation();
            } catch (InterruptedException ex) {
                Logger.getLogger(PainelSimulacoes.class.getName()).log(Level.SEVERE, null, ex);
            }
            threadExecution = null;
            AptoParaSimulacao = false;
            SISMAControle.mensagemJLabel.setText("Ready !");
        }
    }

    public XYSeriesCollection getDataset() {
        return dataset;
    }

    public void ClearXYSerie() {
        dataset.removeAllSeries();
    }

    public boolean isPausado() {
        return pausado;
    }

    public void setPausado(boolean t) {
        pausado = t;
    }

    @Override
    public String toString() {
        if (ExisteRelatorio()) {
            return relatorio;
        } else {
            return "None map was created to generate one report";
        }
    }
}
