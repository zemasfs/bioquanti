package Draw;

/*
 * DrawComposto.java
 *
 * Created on 28 de Fevereiro de 2008, 11:38
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
import Core.*;
import Interfaces.*;
import java.awt.*;
import java.awt.event.*;
import java.io.Serializable;
import javax.swing.*;

/**
 * O objetivo desta classe é desenhar um composto
 *
 * @author José Alexandre Macedo
 * @author Neubio Matos Ferreira
 */
public class DrawComposto extends JLabel
        implements MouseListener, MouseMotionListener, Serializable {

    private Rectangle retangulo;
    private Composto comp;
    private Mapa mapa;
    private DrawConector[] conectores;
    private JMenuItem remove;
    private JMenuItem properties;

    /**
     * Constroi o desenho de um composto de acordo com um objeto composto e o
     * mapa ao qual este pertence.
     *
     * @param comp - composto com suas informações para tornar possível a
     * criação do desenho do composto
     * @param mapa - mapa ao qual o composto pertence
     */
    public DrawComposto(Composto comp, Mapa mapa) {

        this.comp = comp;
        this.mapa = mapa;

        conectores = new DrawConector[12];

        conectores[0] = new DrawConector(1, comp);
        conectores[1] = new DrawConector(2, comp);
        conectores[2] = new DrawConector(3, comp);
        conectores[3] = new DrawConector(4, comp);
        conectores[4] = new DrawConector(5, comp);
        conectores[5] = new DrawConector(6, comp);
        conectores[6] = new DrawConector(7, comp);
        conectores[7] = new DrawConector(8, comp);
        conectores[8] = new DrawConector(9, comp);
        conectores[9] = new DrawConector(10, comp);
        conectores[10] = new DrawConector(11, comp);
        conectores[11] = new DrawConector(12, comp);

        remove = new JMenuItem("Remove");
        properties = new JMenuItem("Properties");

        createEventosPopUpMenu();

        JPopupMenu menu = new JPopupMenu("Menu");
        menu.add(remove);
        menu.addSeparator();
        menu.add(properties);
        setComponentPopupMenu(menu);

        setBounds(comp.MostraPosX(), comp.MostraPosY(), 120, 30);
        setForeground(comp.getCor());
        setNome(comp.getNome());

        setToolTipText("Click here for configuration this Object");
        setVisible(true);
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    public void removeVias() {
        Via viaTemp;
        for (DrawConector conect : getConectores()) {
            if (conect.existeVia()) {
                viaTemp = conect.getVia();
                mapa.removeVia(conect.getVia());
                viaTemp.getCntA().addVia(null);
                viaTemp.getCntB().addVia(null);
            }
        }
        mapa.repaint();
    }

    public void removeComposto() {
        //Composto compTemp;
        mapa.removeComposto(comp);

    }

    /**
     * M�todo sobreescrito pois al�m de mudar a posi��o do desenho do composto
     * tamb�m tem que mudar a posi��o dos conectores que est�o ligados a este
     * composto
     *
     * @param x - nova posi��o no eixo x
     * @param y - nova posi��o no eixo y
     * @param k - largura a partir do ponto x
     * @param j - altura a partir do ponto y
     */
    public void setBounds(int x, int y, int k, int j) {
        super.setBounds(x + 30, y, 120, 30);
        conectores[0].setBounds(getLocation().x + 22, getLocation().y - 37, 10, 30);
        conectores[1].setBounds(getLocation().x + 59, getLocation().y - 37, 10, 30);
        conectores[2].setBounds(getLocation().x - 12, getLocation().y - 13, 10, 30);
        conectores[3].setBounds(getLocation().x + 125, getLocation().y - 13, 10, 30);
        conectores[4].setBounds(getLocation().x + 22, getLocation().y + 12, 10, 30);
        conectores[5].setBounds(getLocation().x + 59, getLocation().y + 12, 10, 30);
        conectores[6].setBounds(getLocation().x - 12, getLocation().y + 12, 10, 30);
        conectores[7].setBounds(getLocation().x + 125, getLocation().y - 37, 10, 30);
        conectores[8].setBounds(getLocation().x - 12, getLocation().y - 37, 10, 30);
        conectores[9].setBounds(getLocation().x + 125, getLocation().y + 12, 10, 30);
        conectores[10].setBounds(getLocation().x + 93, getLocation().y + 12, 10, 30);
        conectores[11].setBounds(getLocation().x + 93, getLocation().y - 37, 10, 30);
    }

    /**
     * M�todo que me passa todos os conectores que pertencem ao desenho de um
     * composto.
     *
     * @return um vetor com todos os conectores do desenho do composto
     */
    public DrawConector[] getConectores() {
        return conectores;
    }

    /**
     * M�todo que me mostra o conector 1
     *
     * @return conector 1
     */
    public DrawConector getCnt1() {
        return conectores[0];
    }

    /**
     * M�todo que me mostra o conector 2
     *
     * @return conector 2
     */
    public DrawConector getCnt2() {
        return conectores[1];
    }

    /**
     * M�todo que me mostra o conector 3
     *
     * @return conector 3
     */
    public DrawConector getCnt3() {
        return conectores[2];
    }

    /**
     * M�todo que me mostra o conector 4
     *
     * @return conector 4
     */
    public DrawConector getCnt4() {
        return conectores[3];
    }

    /**
     * M�todo que me mostra o conector 5
     *
     * @return conector 5
     */
    public DrawConector getCnt5() {
        return conectores[4];
    }

    /**
     * M�todo que me mostra o conector 6
     *
     * @return conector 6
     */
    public DrawConector getCnt6() {
        return conectores[5];
    }

    /**
     * M�todo que modifica a cor do desenho do composto de acordo com a cor do
     * composto ao qual ele est� vinculado.
     */
    public void setCorComposto() {
        setForeground(comp.getCor());
    }

    /**
     * M�todo que modifica o nome do desenho do composto
     *
     * @param nome - novo nome que ser� desenhado
     */
    public void setNome(String nome) {
        String nomefim = "";
        for (int i = 0; i < 12 - comp.getNome().length(); i++) {
            nomefim += " ";
        }
        nome = nomefim + nome;
        setFont(new Font("Arial", Font.BOLD, 18));
        setText(nome);
    }

    public void createEventosPopUpMenu() {
        remove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeVias();
                removeComposto();
            }
        });

        properties.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mouseClicked(null);
            }
        });
    }

    public void setCorConectores(boolean simulando) {
        for (DrawConector conect : getConectores()) {
            conect.setColorConect(simulando);
        }
    }

    public DrawConector getConector(int id) {
        return conectores[id - 1];
    }

    /**
     * M�todo chamado depois de pressionar o bot�o e soltar rapidamente
     *
     * @param event - evento do mouse
     */
    public void mouseClicked(MouseEvent event) {
        if (PainelSimulacoes.AptoParaSimulacao == false) {
            JFrame Painel = new JFrame("Sisma - Object Properties");
            Painel.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            Painel.setUndecorated(true);
            Painel.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
            Painel.setSize(350, 300);
            Painel.setResizable(false);
            Painel.setBackground(Color.BLACK);
            Painel.setLocation(280, 60);
            InfoComposto painelInfo = new InfoComposto(comp, Painel, mapa);
            painelInfo.setInformacoes();
            Painel.add(painelInfo);
            Painel.setVisible(true);
            painelInfo.ganharFocus();
        }

    }

    /**
     * M�todo chamado qdo � pressionado o bot�o do mouse
     *
     * @param event - evento do mouse
     */
    public void mousePressed(MouseEvent event) {

    }

    /**
     * M�todo chamado qdo o bot�o � solto apos ararastar um objeto
     *
     * @param event - evento do mouse
     */
    public void mouseReleased(MouseEvent event) {

    }

    /**
     * M�todo chamado qdo o mouse entra no painel
     *
     * @param event - evento do mouse
     */
    public void mouseEntered(MouseEvent event) {

    }

    /**
     * M�todo chamado qdo o mouse sai do painel
     *
     * @param event - evento do mouse
     */
    public void mouseExited(MouseEvent event) {

    }

    // MouseMotionListener event handlers
    /**
     * M�todo chamado qdo um usuario arrasta o objeto com o bot�o pressionado
     *
     * @param event - evento do mouse
     */
    public void mouseDragged(MouseEvent event) {
        if (PainelSimulacoes.AptoParaSimulacao == false) {
            retangulo = getBounds();
            int iX = event.getX();
            int iY = event.getY();

            int totX;
            int totY;
            double totalX = retangulo.getX();
            double totalY = retangulo.getY();

            //Variaveis para colocar o objeto no centro da posi��o clicada
            int largura, altura;
            largura = retangulo.width;
            altura = retangulo.height;

            totX = (iX + (int) totalX) - (largura / 2);
            totY = (iY + (int) totalY) - (altura / 2);

            setBounds(totX + 30, totY, 120, 30);
            comp.setPosXY(totX + 30, totY);

            mapa.repaint();
        }
    }

    /**
     * M�todo chamado qdo o usuario move o mouse
     *
     * @param event - evento do mouse
     */
    public void mouseMoved(MouseEvent event) {

    }

}
