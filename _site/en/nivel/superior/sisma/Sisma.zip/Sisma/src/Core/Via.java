package Core;

import Equacao.Equation;
import Interfaces.PainelSimulacoes;
import Draw.DrawConector;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.Serializable;

/*
 * Via.java
 *
 * Created on 22 de Fevereiro de 2008, 12:20
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
/**
 * O objetivo dessa classe � criar e possibilitar a manipula��o de uma via
 *
 * @author Jos� Alexandre Macedo
 * @author Neubio Matos Ferreira
 */
public class Via implements Serializable {

    private DrawConector cntA;
    private DrawConector cntB;

    private int posIniX, posIniY, posCtrlX, posCtrlY, posFimX, posFimY;

    private Composto A;
    private Composto B;

    private Interferencia interferencia;

    //Taxa � o valor que � transferido de A para B, calculada com o auxilio das
    //constantes Kab e Ki.
    private double taxa;

    private boolean simulando;

    private Equation equacao;

    private String infoEq;

    private AnimationVia animationVia;

    /**
     * Construir uma via que possui as seguintes informa��es: Dois conectores
     * cada um de um composto (cntA , cntB) e uma constante Kab.
     *
     * @param cntA - Indica o conector ligado a um composto A
     * @param cntB - Indica o conector ligado a um composto B
     * @param Kab - Constante que calcula a quantidade que sera transferida de A
     * para B.
     */
    public Via(DrawConector cntA, DrawConector cntB) {
        this.A = cntA.getComposto();
        this.B = cntB.getComposto();
        this.cntA = cntA;
        this.cntB = cntB;
        cntA.addVia(this);
        cntB.addVia(this);
        this.equacao = new Equation("((" + this.A.getNome() + "*Vm)/(" + this.A.getNome() + "+Km))", this);
        equacao.SetVar('C', 50);
        interferencia = new Interferencia();
        interferencia.setQuantidade(3);
        interferencia.setExiste(false);
        simulando = false;
        infoEq = "";
        /*Estou setando a  via em suas devidas posi��es*/
        this.posIniX = (int) cntA.getLocation().getX();
        this.posIniY = (int) cntA.getLocation().getY();
        this.posCtrlX = (int) cntB.getLocation().getX();
        this.posCtrlY = (int) cntB.getLocation().getY();
        this.posFimX = posCtrlX;
        this.posFimY = posCtrlY;

        this.taxa = 1;

        preparaVia();
    }

    public Via(DrawConector cntA, double ctrlX, double ctrlY, DrawConector cntB) {
        this.A = cntA.getComposto();
        this.B = cntB.getComposto();
        this.cntA = cntA;
        this.cntB = cntB;
        cntA.addVia(this);
        cntB.addVia(this);
        this.equacao = new Equation("((" + this.A.getNome() + "*Vm)/(" + this.A.getNome() + "+Km))", this);
        equacao.SetVar('C', 50);
        interferencia = new Interferencia();
        interferencia.setQuantidade(3);
        interferencia.setExiste(false);
        simulando = false;
        infoEq = "";
        /*Estou setando a  via em suas devidas posi��es*/
        this.posIniX = (int) cntA.getLocation().getX();
        this.posIniY = (int) cntA.getLocation().getY();
        this.posCtrlX = (int) ctrlX;
        this.posCtrlY = (int) ctrlY;
        this.posFimX = (int) cntB.getLocation().getX();
        this.posFimY = (int) cntB.getLocation().getY();

        this.taxa = 1;

        preparaVia();
    }

    public void preparaVia() {
        this.animationVia = new AnimationVia(A.getMapaComposto(), this, PainelSimulacoes.veloc);
    }

    public Interferencia getInterferencia() {
        return interferencia;
    }

    public void setInterferencia(Interferencia interferencia) {
        this.interferencia = interferencia;
    }

    public int getPosCtrlX() {
        return posCtrlX;
    }

    public int getPosCtrlY() {
        return posCtrlY;
    }

    /**
     * M�todo que desenha a via de acordo com suas posi��es
     *
     * @param g - local onde a via ser� desenhada
     */
    public void DrawVia(Graphics g) {
        AtualizaPosVia();
        g.setColor(Color.BLACK);
        Mapa.arrow.drawArrow((Graphics2D) g, posIniX + 5, posIniY + 30, posCtrlX + 5, posCtrlY + 30, posFimX + 5, posFimY + 30);
        //seta.DrawArrow2((Graphics2D)g ,posIniX+5 ,posIniY+30 ,posFimX+5 ,posFimY+30);
        //g.drawLine(posIniX+5,posIniY+30,posFimX+5,posFimY+30);
    }

    /**
     * M�todo que atualiza a posi��o das vias de acordo com a posi��o dos
     * conectores aos quais ela esta ligada.
     */
    public void AtualizaPosVia() {
        this.posIniX = (int) cntA.getLocation().getX();
        this.posIniY = (int) cntA.getLocation().getY();
        if (posFimX == posCtrlX && posFimY == posCtrlY) {
            this.posFimX = (int) cntB.getLocation().getX();
            this.posFimY = (int) cntB.getLocation().getY();
            this.posCtrlX = this.posFimX;
            this.posCtrlY = this.posFimY;
        } else {
            this.posFimX = (int) cntB.getLocation().getX();
            this.posFimY = (int) cntB.getLocation().getY();
        }
    }

    /**
     * Método que calcula a taxa que será tranferida de um composto para outro
     * utilizando equações ja estabelecidas( para competitivo, não competitivo e
     * normal)
     *
     * @return retorna o valor da taxa calculada
     */
    public double CalculaTaxaFinal() {

        taxa = equacao.Evaluate();
        //if (taxa>A.getVolume())
        //    taxa = A.getVolume();

        return taxa;
    }

    /**
     * Method which show the final rate
     *
     * @return the final rate
     */
    public double getTaxaFinal() {
        return taxa;
    }

    /**
     * Method which returns the compound A which is connected by the path
     * 
     * @return the compound A
     */
    public Composto getCompoundA() {
        return A;
    }

    /**
     * Method which returns the compound B which is connected by the path
     * 
     * @return the compound B
     */
    public Composto getCompoundB() {
        return B;
    }

    /**
     * M�todo que executa a tranfer�ncia de um composto para outro seguindo
     * algumas regra:
     *
     * - Quando n�o existir volume suficiente no composto A (porque a taxa �
     * maoir que o volume de A),todo o volume de A ser� passado para B,se B n�o
     * ultrapassar o seu limite, ent�o o composto B poder� receber todo o volume
     * de A.
     *
     * - Quando n�o existir volume suficiente no composto A (porque a taxa �
     * maoir que o volume de A),todo o volume de A ser� passado para B,se B
     * ultrapassar o seu limite, ent�o o composto B s� recebera de A o
     * necessario para atingir o seu limite.
     *
     * - Quando existir volume suficiente no composto A, por�m B ultrapassa o
     * seu limite se somado a taxa , ent�o B s� recebera de A o necessario para
     * atingir o seu limite.
     *
     * - Quando existir volume suficiente no composto A e B n�o ultrapassar o
     * seu limite se somado a taxa , ent�o B recebera de A a taxa.
     *
     */
    public void AplicaTranferencia() {

        /*Quando n�o existir volume suficiente no composto A (porque a taxa � maoir que
        *o volume de A),todo o volume de A ser� passado para B,se B n�o ultrapassar
        *o seu limite, ent�o o composto B poder� receber todo o volume de A.
         */
        if ((A.getVolume() - taxa) <= 0) {
            B.AddVolume(A.getVolume());
            A.RemoveVolume(A.getVolume());
        }

        /*Quando n�o existir volume suficiente no composto A (porque a taxa � maoir que
        *o volume de A),todo o volume de A ser� passado para B,se B ultrapassar
        *o seu limite, ent�o o composto B s� recebera de A o necessario para atingir
        *o seu limite.
         */
        // if( ( A.getVolume() - taxa ) <= 0 && (A.getVolume()+B.getVolume()) >= 100){
        //    B.setVolume(100);
        //    A.RemoveVolume(100-B.getVolume());
        //}

        /*Quando existir volume suficiente no composto A, por�m B ultrapassa o seu limite
        *se somado a taxa , ent�o B s� recebera de A o necessario para atingir o seu
        *limite.
         */
        if ((A.getVolume() - taxa) > 0) {
            A.RemoveVolume(taxa);
            B.AddVolume(taxa);
        }

        /*Quando existir volume suficiente no composto A e B n�o ultrapassar o seu limite
        *se somado a taxa , ent�o B recebera de A a taxa.
         */
        // if( ( A.getVolume() - taxa ) > 0 && ( B.getVolume()+taxa ) < 100 ){
        //     B.AddVolume(taxa);
        //     A.RemoveVolume(taxa);
        //  }
    }

    /**
     * Informa��ens sobre a via e os compostos que est�o sendo ligados por ela.
     *
     * @return as informa��es da via
     */
    @Override
    public String toString() {
        return "Via do composto " + A.getNome() + " para o Composto " + B.getNome() + " :\n"
                + "Composto " + A.getNome() + " com volume: " + A.getVolume() + "\n"
                + "Composto " + B.getNome() + " com volume: " + B.getVolume() + "\n"
                + "Valor da taxa de tranferencia: " + taxa + "\n\n";
    }

    public DrawConector getCntA() {
        return cntA;
    }

    public DrawConector getCntB() {
        return cntB;
    }

    public void setSimulando(boolean x) {
        simulando = x;
    }

    public boolean getSimulando() {
        return simulando;
    }

    public void setEquation(String nome) {
        equacao = new Equation(nome, this);
    }

    public String getEquation() {
        return equacao.toString();
    }

    public Equation getEquation2() {
        return equacao;
    }

    public void setInfoEq(String x) {
        this.infoEq = x;
    }

    public String getInfoEq() {
        return this.infoEq;
    }

    public AnimationVia getAnimationExecution() {
        return animationVia;
    }
}
