/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Functions;

import Core.Composto;
import Core.Mapa;
import Core.Via;
import Draw.DrawAreaTexto;
import Draw.DrawImagem;
import Equacao.Variable;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

/**
 *
 * @author aluno
 */
public class XMLFile {

    public static void CreateXMLFileV085(Mapa map, String path) throws IOException {
        //Declaração dos elementos que irão compor a estrutura do documento.
        Element mapa = new Element("mapa");
        mapa.setAttribute("versao", "0.8.5");
        mapa.setAttribute("nome", map.getNome());
        Element compostos = new Element("compostos");
        for (Composto c : map.getCompostos()) {
            Element composto = new Element("composto");
            composto.setAttribute("id", c.getId() + "");
            composto.setAttribute("nome", c.getNome());
            composto.setAttribute("cor", c.getGrupo());
            composto.setAttribute("level", c.getVolume() + "");
            composto.setAttribute("plot", c.getPlot() + "");
            composto.setAttribute("init", c.isInit() + "");
            composto.setAttribute("posX", c.MostraPosX() + "");
            composto.setAttribute("posY", c.MostraPosY() + "");
            compostos.addContent(composto);
        }
        Element vias = new Element("vias");
        for (Via v : map.getVias()) {
            Element via = new Element("via");
            via.setAttribute("idCompostoA", v.getCompoundA().getId() + "");
            via.setAttribute("idConectorA", v.getCntA().getId() + "");
            via.setAttribute("idCompostoB", v.getCompoundB().getId() + "");
            via.setAttribute("idConectorB", v.getCntB().getId() + "");
            via.setAttribute("equation", v.getEquation() + "");            
            via.setAttribute("infoEq", v.getInfoEq()+ "");
            Element variaveis = new Element("variaveis");
            for (Variable var : v.getEquation2().GetListVariables()) {
                Element variavel = new Element("variavel");
                variavel.setAttribute("nome", var.getFantasyName());
                variavel.setAttribute("valor", var.getValor() + "");
                variaveis.addContent(variavel);
            }
            via.addContent(variaveis);
            vias.addContent(via);
        }
        Element DrawAreasTexto = new Element("DrawAreasTexto");
        for (DrawAreaTexto a : map.getAreasDeTexto()) {
            Element DrawAreaTexto = new Element("DrawAreaTexto");
            DrawAreaTexto.setAttribute("texto", a.getText());
            DrawAreaTexto.setAttribute("posicaoX", a.getBounds().getX() + "");
            DrawAreaTexto.setAttribute("posicaoY", a.getBounds().getY() + "");
            DrawAreaTexto.setAttribute("width", a.getBounds().getWidth() + "");
            DrawAreaTexto.setAttribute("height", a.getBounds().getHeight() + "");
            DrawAreasTexto.addContent(DrawAreaTexto);
        }

        //Criando o documento XML (montado)
        mapa.addContent(compostos);
        mapa.addContent(vias);
        mapa.addContent(DrawAreasTexto);

        Document doc = new Document();

        doc.setRootElement(mapa);

        //Imptrimindo o XML
        XMLOutputter xout = new XMLOutputter();
        Format fxml = Format.getPrettyFormat();
        fxml.setEncoding("UTF-8");
        xout.setFormat(fxml);
        xout.output(doc, new FileWriter(path));

    }

    public static void CreateXMLFileV100(Mapa map, String path) throws IOException {
        //Declara��o dos elementos que ir�o compor a estrutura do documento.
        Element mapa = new Element("mapa");
        mapa.setAttribute("versao", "1.0.0");
        mapa.setAttribute("nome", map.getNome());
        Element compostos = new Element("compostos");
        for (Composto c : map.getCompostos()) {
            Element composto = new Element("composto");
            composto.setAttribute("id", c.getId() + "");
            composto.setAttribute("nome", c.getNome());
            composto.setAttribute("cor", c.getGrupo());
            composto.setAttribute("level", c.getVolume() + "");
            composto.setAttribute("plot", c.getPlot() + "");
            composto.setAttribute("init", c.isInit() + "");
            composto.setAttribute("posX", c.MostraPosX() + "");
            composto.setAttribute("posY", c.MostraPosY() + "");
            compostos.addContent(composto);
        }
        Element vias = new Element("vias");
        for (Via v : map.getVias()) {
            Element via = new Element("via");
            via.setAttribute("idCompostoA", v.getCompoundA().getId() + "");
            via.setAttribute("idConectorA", v.getCntA().getId() + "");
            via.setAttribute("crtlX", v.getPosCtrlX() + "");
            via.setAttribute("crtlY", v.getPosCtrlY() + "");
            via.setAttribute("idCompostoB", v.getCompoundB().getId() + "");
            via.setAttribute("idConectorB", v.getCntB().getId() + "");
            via.setAttribute("interferenciaQuantidade", v.getInterferencia().getQuantidade() + "");
            via.setAttribute("interferenciaExiste", v.getInterferencia().isExiste() + "");
            via.setAttribute("equation", v.getEquation() + "");            
            via.setAttribute("infoEq", v.getInfoEq()+ "");
            Element variaveis = new Element("variaveis");
            for (Variable var : v.getEquation2().GetListVariables()) {
                Element variavel = new Element("variavel");
                variavel.setAttribute("nome", var.getFantasyName());
                variavel.setAttribute("valor", var.getValor() + "");
                variaveis.addContent(variavel);
            }
            via.addContent(variaveis);
            vias.addContent(via);
        }
        Element DrawAreasTexto = new Element("DrawAreasTexto");
        for (DrawAreaTexto a : map.getAreasDeTexto()) {
            Element DrawAreaTexto = new Element("DrawAreaTexto");
            //Element texto = new Element("texto");
            //texto.addContent(a.getText());
            DrawAreaTexto.setAttribute("texto", a.getText());
            DrawAreaTexto.setAttribute("posicaoX", a.getBounds().getX() + "");
            DrawAreaTexto.setAttribute("posicaoY", a.getBounds().getY() + "");
            DrawAreaTexto.setAttribute("width", a.getBounds().getWidth() + "");
            DrawAreaTexto.setAttribute("height", a.getBounds().getHeight() + "");
            DrawAreasTexto.addContent(DrawAreaTexto);
        }

        Element DrawImagens = new Element("DrawImagens");
        for (DrawImagem a : map.getImagens()) {
            Element DrawImagem = new Element("DrawImagem");
            DrawImagem.setAttribute("imagemBase64", a.getBase64());
            DrawImagem.setAttribute("posicaoX", a.getBounds().getX() + "");
            DrawImagem.setAttribute("posicaoY", a.getBounds().getY() + "");
            DrawImagem.setAttribute("width", a.getBounds().getWidth() + "");
            DrawImagem.setAttribute("height", a.getBounds().getHeight() + "");
            DrawImagens.addContent(DrawImagem);
        }

        //Criando o documento XML (montado)
        mapa.addContent(compostos);
        mapa.addContent(vias);
        mapa.addContent(DrawAreasTexto);
        mapa.addContent(DrawImagens);

        Document doc = new Document();

        doc.setRootElement(mapa);

        //Imptrimindo o XML
        XMLOutputter xout = new XMLOutputter();
        Format fxml = Format.getPrettyFormat();
        fxml.setEncoding("UTF-8");
        xout.setFormat(fxml);
        xout.output(doc, new FileWriter(path));

    }

    public static Mapa ReadXML(String path) throws JDOMException, IOException {

        //Criamos uma classe SAXBuilder que vai processar o XML4
        SAXBuilder sb = new SAXBuilder();

        //Este documento agora possui toda a estrutura do arquivo.
        Document d = sb.build(new File(path));

        //Recuperamos o elemento root
        Element map = d.getRootElement();
        //Recuperamos os elementos filhos (children)
        List elements = map.getChildren();
        Iterator i = elements.iterator();

        Mapa mapa;

        //Element element = (Element) i.next();
        String versao = map.getAttributeValue("versao");
        String nomeMapa = map.getAttributeValue("nome");
        mapa = new Mapa(nomeMapa);

        System.out.println(versao + " " + nomeMapa);

        if (versao.equals("0.8.5")) {
            //Iteramos com os elementos filhos, e filhos do dos filhos
            return getMapaV085(mapa, i);

        } else if (versao.equals("1.0.0")) {

            return getMapaV100(mapa, i);

        } else {
            return null;
        }
    }

    public static Mapa getMapaV085(Mapa mapa, Iterator i) {
        if (i.hasNext()) {
            Element element = (Element) i.next();
            List compostos = element.getChildren();
            Iterator iComp = compostos.iterator();
            while (iComp.hasNext()) {
                Element composto = (Element) iComp.next();
                String id = (composto).getAttributeValue("id");
                //System.out.println("id: "+id);
                String nome = (composto).getAttributeValue("nome");
                String cor = (composto).getAttributeValue("cor");
                String level = (composto).getAttributeValue("level");
                boolean plot, init;
                if ((composto).getAttributeValue("plot").equals("true")) {
                    plot = true;
                } else {
                    plot = false;
                }
                if ((composto).getAttributeValue("init").equals("true")) {
                    init = true;
                } else {
                    init = false;
                }
                String posX = (composto).getAttributeValue("posX");
                String posY = (composto).getAttributeValue("posY");

                Composto object = new Composto(mapa, cor, nome, Double.parseDouble(level), Integer.parseInt(posX), Integer.parseInt(posY));
                object.setPlot(plot);
                object.setInit(init);
                object.setId(Integer.parseInt(id));
                mapa.addComposto(object);
                System.out.println(object);
            }
        }
        ///entra nas Vias e adiciona todas as vias aos mapas
        if (i.hasNext()) {
            List vias = ((Element) i.next()).getChildren();
            Iterator iVia = vias.iterator();
            while (iVia.hasNext()) {
                Element via = (Element) iVia.next();
                Composto a = null;
                Composto b = null;
                int idConectA = Integer.parseInt(via.getAttributeValue("idConectorA"));
                int idConectB = Integer.parseInt(via.getAttributeValue("idConectorB"));
                int idCompA = Integer.parseInt(via.getAttributeValue("idCompostoA"));
                int idCompB = Integer.parseInt(via.getAttributeValue("idCompostoB"));
                String infoEq =  via.getAttributeValue("infoEq");
                for (Composto t : mapa.getCompostos()) {
                    if (t.getId() == idCompA) {
                        a = t;
                    }
                    if (t.getId() == idCompB) {
                        b = t;
                    }
                }
                String equacao = via.getAttributeValue("equation");

                Via viaMapa = new Via(a.getDesenhoComposto().getConector(idConectA), b.getDesenhoComposto().getConector(idConectB));
                viaMapa.setEquation(equacao);
                viaMapa.setInfoEq(infoEq);
                List pegandoVariaveis = via.getChildren();
                Element var = (Element) (pegandoVariaveis.iterator()).next();
                List variaveis = var.getChildren();
                Iterator iVariavel = variaveis.iterator();
                while (iVariavel.hasNext()) {
                    Element variavel = (Element) iVariavel.next();
                    String nomeVar = variavel.getAttributeValue("nome");
                    //System.out.println("nome var "+nomeVar);
                    double valorVar = Double.parseDouble(variavel.getAttributeValue("valor"));
                    viaMapa.getEquation2().SetVar(nomeVar, valorVar);
                }
                mapa.addVia(viaMapa);
            }
        }
        if (i.hasNext()) {
            List DrawAreas = ((Element) i.next()).getChildren();
            Iterator iAreas = DrawAreas.iterator();
            while (iAreas.hasNext()) {
                Element DrawArea = (Element) iAreas.next();
                String conteudo = DrawArea.getAttributeValue("texto");
                System.out.println("conteudo " + conteudo);
                int posX = (int) (Double.parseDouble(DrawArea.getAttributeValue("posicaoX")));
                int posY = (int) (Double.parseDouble(DrawArea.getAttributeValue("posicaoY")));
                int largura = (int) (Double.parseDouble(DrawArea.getAttributeValue("width")));
                int altura = (int) (Double.parseDouble(DrawArea.getAttributeValue("height")));

                DrawAreaTexto areaText = new DrawAreaTexto(mapa, posX, posY);
                areaText.setBounds(posX, posY, largura, altura);
                areaText.setBordaX(largura);
                areaText.setBordaY(altura);
                areaText.setText(conteudo);
                mapa.addAreaText(areaText);
            }
        }

        return mapa;
    }

    public static Mapa getMapaV100(Mapa mapa, Iterator i) {
        if (i.hasNext()) {
            Element element = (Element) i.next();
            List compostos = element.getChildren();
            Iterator iComp = compostos.iterator();
            while (iComp.hasNext()) {
                Element composto = (Element) iComp.next();
                String id = (composto).getAttributeValue("id");
                //System.out.println("id: "+id);
                String nome = (composto).getAttributeValue("nome");
                String cor = (composto).getAttributeValue("cor");
                String level = (composto).getAttributeValue("level");
                boolean plot, init;
                if ((composto).getAttributeValue("plot").equals("true")) {
                    plot = true;
                } else {
                    plot = false;
                }
                if ((composto).getAttributeValue("init").equals("true")) {
                    init = true;
                } else {
                    init = false;
                }
                String posX = (composto).getAttributeValue("posX");
                String posY = (composto).getAttributeValue("posY");

                Composto object = new Composto(mapa, cor, nome, Double.parseDouble(level), Integer.parseInt(posX), Integer.parseInt(posY));
                object.setPlot(plot);
                object.setInit(init);
                object.setId(Integer.parseInt(id));
                mapa.addComposto(object);
                System.out.println(object);
            }
        }
        ///entra nas Vias e adiciona todas as vias aos mapas
        if (i.hasNext()) {
            List vias = ((Element) i.next()).getChildren();
            Iterator iVia = vias.iterator();
            while (iVia.hasNext()) {
                Element via = (Element) iVia.next();
                Composto a = null;
                Composto b = null;
                int idConectA = Integer.parseInt(via.getAttributeValue("idConectorA"));
                int idConectB = Integer.parseInt(via.getAttributeValue("idConectorB"));
                int idCompA = Integer.parseInt(via.getAttributeValue("idCompostoA"));
                int idCompB = Integer.parseInt(via.getAttributeValue("idCompostoB"));
                String infoEq =  via.getAttributeValue("infoEq");
                for (Composto t : mapa.getCompostos()) {
                    if (t.getId() == idCompA) {
                        a = t;
                    }
                    if (t.getId() == idCompB) {
                        b = t;
                    }
                }

                int posCrtlX = Integer.parseInt(via.getAttributeValue("crtlX"));
                int posCrtlY = Integer.parseInt(via.getAttributeValue("crtlY"));

                String equacao = via.getAttributeValue("equation");
                int interferenciaQtda = Integer.parseInt(via.getAttributeValue("interferenciaQuantidade"));
                String interferenciaNome = via.getAttributeValue("interferenciaNome");
                boolean interferenciaExiste = via.getAttributeValue("interferenciaExiste").equals("true") ? true : false;
                Via viaMapa = null;
                if (b.getDesenhoComposto().getConector(idConectB).getLocation().x == posCrtlX && b.getDesenhoComposto().getConector(idConectB).getLocation().y == posCrtlY) {
                    viaMapa = new Via(a.getDesenhoComposto().getConector(idConectA), b.getDesenhoComposto().getConector(idConectB));
                } else {
                    viaMapa = new Via(a.getDesenhoComposto().getConector(idConectA), posCrtlX, posCrtlY, b.getDesenhoComposto().getConector(idConectB));
                }
                viaMapa.setEquation(equacao);
                viaMapa.setInfoEq(infoEq);
                List pegandoVariaveis = via.getChildren();
                Element var = (Element) (pegandoVariaveis.iterator()).next();
                List variaveis = var.getChildren();
                Iterator iVariavel = variaveis.iterator();
                while (iVariavel.hasNext()) {
                    Element variavel = (Element) iVariavel.next();
                    String nomeVar = variavel.getAttributeValue("nome");
                    //System.out.println("nome var "+nomeVar);
                    double valorVar = Double.parseDouble(variavel.getAttributeValue("valor"));
                    viaMapa.getEquation2().SetVar(nomeVar, valorVar);
                }
                viaMapa.getInterferencia().setQuantidade(interferenciaQtda);
                viaMapa.getInterferencia().setExiste(interferenciaExiste);
                mapa.addVia(viaMapa);
            }
        }
        if (i.hasNext()) {
            List DrawAreas = ((Element) i.next()).getChildren();
            Iterator iAreas = DrawAreas.iterator();
            while (iAreas.hasNext()) {
                Element DrawArea = (Element) iAreas.next();
                String conteudo = DrawArea.getAttributeValue("texto");
                System.out.println("conteudo " + conteudo);
                int posX = (int) (Double.parseDouble(DrawArea.getAttributeValue("posicaoX")));
                int posY = (int) (Double.parseDouble(DrawArea.getAttributeValue("posicaoY")));
                int largura = (int) (Double.parseDouble(DrawArea.getAttributeValue("width")));
                int altura = (int) (Double.parseDouble(DrawArea.getAttributeValue("height")));

                DrawAreaTexto areaText = new DrawAreaTexto(mapa, posX, posY);
                areaText.setBounds(posX, posY, largura, altura);
                areaText.setBordaX(largura);
                areaText.setBordaY(altura);
                areaText.setText(conteudo);
                mapa.addAreaText(areaText);
            }
        }

        if (i.hasNext()) {
            List DrawImagens = ((Element) i.next()).getChildren();
            Iterator iImagens = DrawImagens.iterator();
            while (iImagens.hasNext()) {
                Element DrawImagem = (Element) iImagens.next();
                String caminho = DrawImagem.getAttributeValue("caminho");
                String imgBase64 = DrawImagem.getAttributeValue("imagemBase64");
                int posX = (int) (Double.parseDouble(DrawImagem.getAttributeValue("posicaoX")));
                int posY = (int) (Double.parseDouble(DrawImagem.getAttributeValue("posicaoY")));
                int largura = (int) (Double.parseDouble(DrawImagem.getAttributeValue("width")));
                int altura = (int) (Double.parseDouble(DrawImagem.getAttributeValue("height")));
                
                DrawImagem img;
                if(caminho != null){
                    img = new DrawImagem(caminho, mapa);
                }else{
                    img = new DrawImagem(mapa, imgBase64);
                }
                            
                img.setBounds(posX, posY, largura, altura);
                img.setLargura(largura);
                img.setAltura(altura);
                img.setPosIniX(posX);
                img.setPosIniY(posY);
                mapa.addImagemMapa(img);

            }
        }

        return mapa;
    }
}
