package Functions;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JPanel;

/*
 * SalvaJPEG.java
 *
 * Created on 31 de Março de 2008, 11:48
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
/**
 *
 * @author CCOMP
 */
public class SalvaJPEG {

    private static SalvaJPEG instance;

    public SalvaJPEG() {
    }

    public static SalvaJPEG getInstance() {
        if (instance == null) {
            instance = new SalvaJPEG();
        }
        return instance;
    }

    public void encode(JPanel p, OutputStream out) throws Exception {

        BufferedImage imagem = new BufferedImage(
                p.getBounds().width,
                p.getBounds().height,
                BufferedImage.TYPE_INT_RGB);
        Graphics gfx = imagem.createGraphics();
        p.printAll(gfx);
        try {
            ImageIO.write(imagem, "jpg", out);
        } catch (IOException exp) {
            exp.printStackTrace();
        }
    }

    public void salvaImagem(JPanel painel) {
        try {
            JFileChooser chooser = new JFileChooser();

            int option = chooser.showSaveDialog(painel);
            OutputStream out = new FileOutputStream(chooser.getSelectedFile().getPath() + ".jpeg");

            encode(painel, out);
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("pipoca2");

        } catch (Exception e) {
            System.out.println("pipoca");
        }
    }

}
