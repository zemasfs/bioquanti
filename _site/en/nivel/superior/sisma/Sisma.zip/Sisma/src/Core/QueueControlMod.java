/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Core;

import Draw.DrawConector;
import Interfaces.PainelSimulacoes;
import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author Nicolas Bontempo
 */
public class QueueControlMod implements Runnable {

    private Mapa Mapa;
    private PainelSimulacoes painelSimulacoes;
    private Queue<Composto> queueOfCompound;
    private Queue<Via> queueOfPath;

    private int time;

    public QueueControlMod(Mapa mapa, PainelSimulacoes painelSimulacoes) {
        this.Mapa = mapa;
        this.queueOfCompound = new LinkedList<Composto>();
        this.queueOfPath = new LinkedList<Via>();
        this.painelSimulacoes = painelSimulacoes;
    }

    public void addFirstCompound(Composto c) {
        queueOfCompound.add(c);
    }

    private void getTime(int time) {
        this.time = time;
    }

    private void setTime(int time) {
        this.time = time;
    }

    @Override
    public void run() {
        for (Composto x : Mapa.getCompostos())
            x.getDesenhoComposto().setCorConectores(true);
        painelSimulacoes.AptoParaSimulacao = true;
        while (!queueOfCompound.isEmpty()) {
            while (!queueOfCompound.isEmpty()) {
                Composto comp = queueOfCompound.poll();
                for (DrawConector conector : comp.getDesenhoComposto().getConectores()) {
                    if (conector.existeVia() && conector.getVia().getCompoundA() == comp
                            && conector.getVia().getCompoundA().getVolume() > 1
                            && conector.getVia().CalculaTaxaFinal() != 0) {
                        queueOfPath.add(conector.getVia());
                    }
                }
            }
            while (!queueOfPath.isEmpty()) {
                Via path = queueOfPath.poll();
                time = path.getAnimationExecution().execute(time);
                if(path.getAnimationExecution().executionFinished())
                    queueOfCompound.add(path.getCompoundB());
                else
                    queueOfPath.add(path);
            }
        }
        for (Composto x : Mapa.getCompostos())
            x.getDesenhoComposto().setCorConectores(false);
        painelSimulacoes.finishAnimation();
    }
}
