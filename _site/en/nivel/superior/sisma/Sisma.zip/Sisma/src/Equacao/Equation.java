package Equacao;

import Core.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Stack;

/*
 * Equation.java
 *
 * Created on 26 de Mar�o de 2008, 12:59
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
/**
 *
 * @author José Alexandre Macedo
 * @author Neubio Matos Ferreira
 */
public class Equation implements Serializable {

    char[] equation;
    String equationString; // nome real
    String equationPosfix;
    ArrayList<Variable> listVariable;
    Via via;

    /**
     * Creates a new instance of Equation
     */
    public Equation() {

    }

    public Equation(String equation, Via via) {
        equation = equation.replaceAll("\\s+", "");
        equation = equation.replaceAll("ln", "!");
        equation = equation.replaceAll("sqrt", "?");
        this.via = via;
        this.equation = acceptEquation(equation).toCharArray();
        this.equationString = equation;
        this.equationPosfix = InfixtoPosfix();
        listVariable = new ArrayList<Variable>();
        criaVariaveis();
    }

    public void criaVariaveis() {
        /* for(char k : this.equation)
            if(IsVariable(k) && !pertence(listVariable,k))
                listVariable.add(new Variable(k)); */

        String eq = equationString;
        eq = eq.replace("+", " ");
        eq = eq.replace("-", " ");
        eq = eq.replace("*", " ");
        eq = eq.replace("^", " ");
        eq = eq.replace("/", " ");
        eq = eq.replace("(", " ");
        eq = eq.replace(")", " ");
        eq = eq.replace("!", " ");
        eq = eq.replace("?", " ");

        String varFantasyName[] = eq.split(" ");
        ArrayList<String> varVantasy = new ArrayList<String>();
        String alfabeto[] = {"C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N"};
        eq = equationString;
        int j = 0;
        for (int i = 0; i < varFantasyName.length; i++) {
            if (!varFantasyName[i].equals("")) {
                if (!varVantasy.contains(varFantasyName[i])
                        && !this.via.getCompoundA().getNome().equals(varFantasyName[i])
                        && !this.via.getCompoundB().getNome().equals(varFantasyName[i])) {
                    varVantasy.add(varFantasyName[i]);
                    listVariable.add(new Variable(alfabeto[j].charAt(0), varVantasy.get(j)));
                    j++;
                }
            }
        }

        /*if(varVantasy.size()<=12){
            for (int i=0; i<varVantasy.size();i++){
                //if(!pertence(listVariable,varVantasy.get(i)))
                    listVariable.add(new Variable(alfabeto[i].charAt(0),varVantasy.get(i)));              
            }
        }
        else System.out.println("Erro na criacao da equacao!!"); */
    }

    public void SetVar(char name, double value) {
        for (Variable k : listVariable) {
            if (k.getNome() == name) {
                k.setValor(value);
            }
        }
    }

    public void SetVar(String name, double value) {
        for (Variable k : listVariable) {
            if (k.getFantasyName().equals(name)) {
                k.setValor(value);
            }
        }
    }

    public String GetFantasyVar(char name) {
        if (name == 'A') {
            return via.getCompoundA().getNome();
        }
        if (name == 'B') {
            return via.getCompoundB().getNome();
        }
        for (Variable k : listVariable) {
            if (k.getNome() == name) {
                return k.getFantasyName();
            }
        }
        return null;
    }

    public double GetValueVar(char name) {
        if (name == 'A') {
            return via.getCompoundA().getVolume();
        }
        if (name == 'B') {
            return via.getCompoundB().getVolume();
        }
        for (Variable k : listVariable) {
            if (k.getNome() == name) {
                return k.getValor();
            }
        }
        return -1;///
    }

    public ArrayList<Variable> GetListVariables() {
        return listVariable;
    }

    public boolean pertence(ArrayList<Variable> list, char k) {
        for (Variable x : list) {
            if (x.getNome() == k) {
                return true;
            }
        }
        return false;
    }

    public boolean existVar(char k) {
        for (Variable x : listVariable) {
            if (x.getNome() == k) {
                return true;
            }
        }
        return false;
    }

    public double Evaluate() {
        Stack<Double> heap = new Stack<Double>();//Stack acha o operadoe e desempilha
        double x, y;
        for (char k : equationPosfix.toCharArray()) {
            if (IsVariable(k)) {
                heap.push(GetValueVar(k));
            }
            if (IsNumber(k)) {
                heap.push(Double.parseDouble("" + k));
            } else if (IsOperator(k)) {
                y = heap.pop();
                x = heap.pop();
                if (k == '+') {
                    heap.push(x + y);
                } else if (k == '-') {
                    heap.push(x - y);
                } else if (k == '*') {
                    heap.push(x * y);
                } else if (k == '/') {
                    if (y == 0) {
                        return -2;
                    }
                    heap.push(x / y);
                } else if (k == '^') {
                    heap.push(Math.pow(x, y));
                }
            } else if (IsFunction(k)) {
                y = heap.pop();
                if (k == '!') {
                    heap.push(Math.log(y));
                } else if (k == '?') {
                    heap.push(Math.sqrt(y));
                }
            }
        }

        return heap.pop();
    }

    public int Prio(char x) {
        if (x == '(') {
            return 1;
        }
        if (x == '+' || x == '-') {
            return 2;
        }
        if (x == '*' || x == '/' || x == '^') {
            return 3;
        } else {
            return 0;
        }
    }

    public String InfixtoPosfix() {
        String S = "";
        char x;

        Stack<Character> pilha = new Stack<Character>();

        char[] equacao = this.equation;

        for (char k : equacao) {
            if (IsNumOrLet(k)) {
                S += k;
            }
            if (IsOperator(k)) {
                while (!pilha.empty() && Prio(pilha.peek()) >= Prio(k)) {
                    S += pilha.pop();
                }
                pilha.push(k);
            }
            if (IsFunction(k)) {
                if (!pilha.empty() && Prio(pilha.peek()) >= Prio(k)) {
                    S += pilha.pop();
                }
                pilha.push(k);
            }
            if (k == '(') {
                pilha.push(k);
            }
            if (k == ')') {
                while (pilha.peek() != '(') {
                    S += pilha.pop();
                }
                x = pilha.pop();
            }
        }
        while (!pilha.empty()) {
            S += pilha.pop();
        }

        return S;
    }

    public boolean IsNumOrLet(char k) {
        return k >= 48 && k <= 57 || k >= 65 && k <= 90 || k >= 97 && k <= 122;
    }

    public boolean IsVariable(char k) {
        return k >= 65 && k <= 90 || k >= 97 && k <= 122;
    }

    public boolean IsNumber(char k) {
        return k >= 48 && k <= 57;
    }

    public boolean IsFunction(char k) {
        return k == '?' || k == '!';
    }

    public boolean IsOperator(char k) {
        return k == '+' || k == '-' || k == '*' || k == '/' || k == '^';
    }

    public void TabelaAscci() {
        for (int i = 0; i < 200; i++) {
            System.out.printf("%d - %c \n", i, i);
        }
    }

    public boolean IsValidEquation(String equation) {
        equation = equation.replaceAll("\\s+", "");
        equation = equation.replaceAll("ln", "!");
        equation = equation.replaceAll("sqrt", "?");
        Equation eq = new Equation();
        int cont1 = 0, cont2 = 0;
        char[] novaEqChar = acceptEquation(equation).toCharArray();
        for (int i = 0; i < novaEqChar.length; i++) {
            if (i == 0 && !eq.IsVariable(novaEqChar[i]) && novaEqChar[i] != '(' && !eq.IsFunction(novaEqChar[i])) {
                return false;
            }
            if (eq.IsVariable(novaEqChar[i])) {
                if ((i + 1) < novaEqChar.length) {
                    if (!eq.IsOperator(novaEqChar[i + 1]) && novaEqChar[i + 1] != ')') {
                        return false;
                    }
                }
            }
            if (eq.IsOperator(novaEqChar[i])) {
                if ((i + 1) < novaEqChar.length) {
                    if (!eq.IsVariable(novaEqChar[i + 1]) && novaEqChar[i + 1] != '(') {
                        return false;
                    }
                } else {
                    return false;
                }
            }
            if (novaEqChar[i] == '(') {
                cont1++;
                if ((i + 1) < novaEqChar.length) {
                    if (!eq.IsVariable(novaEqChar[i + 1]) && novaEqChar[i + 1] != '(') {
                        return false;
                    }
                } else {
                    return false;
                }
            }

            if (novaEqChar[i] == ')') {
                cont2++;
                if ((i + 1) < novaEqChar.length) {
                    if (!eq.IsOperator(novaEqChar[i + 1]) && novaEqChar[i + 1] != ')') {
                        return false;
                    }
                }
            }
        }
        if (cont1 != cont2) {
            return false;
        } else {
            return true;
        }
    }

    public boolean isValidVariables(String x) {
        for (Character y : this.equation) {
            if (y != 'A' && y != 'B' && y != 'C' && y != 'D' && y != 'E' && y != 'F' && y != 'G'
                    && y != 'H' && y != 'I' && y != 'J' && y != 'K' && y != 'L' && y != 'M' && y != 'N'
                    && !IsOperator(y) && y != '(' && y != ')' && !IsFunction(y)) {
                return false;
            }
        }
        return true;
    }

    public String acceptEquation(String equation) {
        equation = equation.replaceAll("\\s+", "");
        equation = equation.replaceAll("ln", "!");
        equation = equation.replaceAll("sqrt", "?");
        String eq = equation;
        //System.out.println(eq);
        eq = eq.replace("+", " ");
        eq = eq.replace("-", " ");
        eq = eq.replace("*", " ");
        eq = eq.replace("/", " ");
        eq = eq.replace("?", " ");
        eq = eq.replace("!", " ");
        eq = eq.replace("(", " ");
        eq = eq.replace(")", " ");
        String varFantasyName[] = eq.split(" ");
        ArrayList<String> varVantasy = new ArrayList<String>();
        String alfabeto[] = {"C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N"};
        eq = equation;

        int j = 0;
        for (int i = 0; i < varFantasyName.length; i++) {
            if (!varFantasyName[i].equals("")) {
                if (!varVantasy.contains(varFantasyName[i])) {
                    varVantasy.add(varFantasyName[i]);
                }
            }
        }
        for (int i = 0; i < varVantasy.size(); i++) {
            if (this.via.getCompoundA().getNome().equals(varVantasy.get(i))) {
                eq = eq.replaceAll(varVantasy.get(i), "A");
            } else {
                if (this.via.getCompoundB().getNome().equals(varVantasy.get(i))) {
                    eq = eq.replaceAll(varVantasy.get(i), "B");
                } else {
                    eq = eq.replaceAll(varVantasy.get(i), alfabeto[j++]);
                }
            }
        }

        System.out.println(eq);
        return eq;
    }

    @Override
    public String toString() {
        String returnEquation = equationString.replaceAll("\\!", "ln");
        returnEquation = returnEquation.replaceAll("\\?", "sqrt");
        return returnEquation;
    }

}
