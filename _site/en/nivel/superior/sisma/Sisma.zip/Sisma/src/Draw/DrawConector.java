package Draw;

import Interfaces.*;
import Core.*;
import Interfaces.InfoVia;
import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.Serializable;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JRootPane;

/*
 * DrawConector.java
 *
 * Created on 10 de Março de 2008, 11:10
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
/**
 *
 * @author CCOMP
 */
public class DrawConector extends JLabel
        implements MouseListener, MouseMotionListener, Serializable {

    private int id;
    private Composto x;
    private Via aprab;
    private JMenuItem remove;
    private JMenuItem properties;

    /**
     * Creates a new instance of DrawConector
     * @param id
     * @param composto
     */
    public DrawConector(int id, Composto x) {

        this.id = id;
        setFont(new Font("Bitstream Vera Serif", Font.BOLD, 40));
        float[] cor = Color.RGBtoHSB(235, 235, 235, null);
        setForeground(Color.getHSBColor(cor[0], cor[1], cor[2]));
        setText(".");
        this.x = x;
        this.aprab = null;
        setToolTipText("Click here for configuration this path");

        remove = new JMenuItem("Remove Path");
        properties = new JMenuItem("Properties");

        createEventosPopUpMenu();
        JPopupMenu menu = new JPopupMenu("Menu");
        menu.add(remove);
        menu.addSeparator();
        menu.add(properties);
        setComponentPopupMenu(menu);

        setVisible(true);
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    public void createEventosPopUpMenu() {

        remove.addActionListener((java.awt.event.ActionEvent evt) -> {
            removeViaConect();
        });

        properties.addActionListener((java.awt.event.ActionEvent evt) -> {
            mouseClicked(null);
        });

    }

    public void addVia(Via aprab) {
        this.aprab = aprab;
    }

    public void removeViaConect() {
        Via viaTemp;
        if (existeVia()) {
            viaTemp = aprab;
            x.getMapaComposto().removeVia(aprab);
            viaTemp.getCntA().addVia(null);
            viaTemp.getCntB().addVia(null);
            x.getMapaComposto().repaint();
        }

    }

    public boolean existeVia() {
        return aprab != null;
    }

    public Composto getComposto() {
        return x;
    }

    public Via getVia() {
        return aprab;
    }

    public int getId() {
        return id;
    }

    public void setColorConect(boolean simulando) {
        if (!simulando) {
            float[] cor = Color.RGBtoHSB(235, 235, 235, null);
            setForeground(Color.getHSBColor(cor[0], cor[1], cor[2]));
        } else {
            setForeground(Color.WHITE);
        }
    }

    @Override
    public void mouseClicked(MouseEvent event) {
        if (PainelSimulacoes.AptoParaSimulacao == false && existeVia()) {
            JFrame Painel = new JFrame("Sisma - Path Properties");
            Painel.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            Painel.setUndecorated(true);
            Painel.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
            Painel.setSize(450, 330);
            Painel.setResizable(false);
            Painel.setBackground(Color.WHITE);
            Painel.setLocation(280, 60);

            InfoVia painelInfo = new InfoVia(aprab, Painel, x.getMapaComposto());
            Painel.add(painelInfo);
            Painel.setVisible(true);
        }

    }

    @Override
    public void mousePressed(MouseEvent event) {

        if (!existeVia() && Mapa.AptoParaCriarVia && Mapa.ArrastoInicial) {

            Mapa.p1 = new Point(this.getX() + 5, this.getY() + 30);
            Mapa.count++;
            Mapa.conectorIniTemp = this;
            Mapa.ArrastoInicial = false;
        }

        if (!existeVia() && this != Mapa.conectorIniTemp && Mapa.AptoParaCriarVia && !Mapa.ArrastoInicial) {
            Mapa.ArrastoInicial = true;
            Mapa.AptoParaCriarVia = false;
            Mapa.conectorFimTemp = this;
            Mapa.p3 = new Point(this.getX() + 5, this.getY() + 30);
            if (Mapa.p2 == null) {
                Mapa.p2 = new Point(this.getX(), this.getY());
            }
            Mapa.count = 0;
            //x.getMapaComposto().posFimX= this.getX()+5;
            //x.getMapaComposto().posFimY= this.getY()+30;
        }

    }

    // evento � chamado qdo o bot�o � solto apos ararastar um objeto
    public void mouseReleased(MouseEvent event) {

    }

    // qdo o mouse entra no painel
    public void mouseEntered(MouseEvent event) {

    }

    // qdo o mouse sai do painel
    public void mouseExited(MouseEvent event) {

    }

    // MouseMotionListener event handlers
    // quando um usuario arrasta o objeto com o bot�o pressionado
    public void mouseDragged(MouseEvent event) {

    }

    // quando o usuario move o mouse
    public void mouseMoved(MouseEvent event) {

    }

}
