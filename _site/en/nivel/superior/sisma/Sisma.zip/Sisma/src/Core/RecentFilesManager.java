/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nickb
 */
public class RecentFilesManager {
    String caminhoArquivoConfiguracao;
    public RecentFilesManager(){
        caminhoArquivoConfiguracao = "." + "config.temp";
//        System.getProperty("user.dir") + "config.temp"
    }
    public LinkedList<RecentFile> ListRecentFiles() {
        InputStream iSConfig = null;
        try {
            File file = new File(caminhoArquivoConfiguracao);
            file.createNewFile();
            iSConfig = new FileInputStream(file);
        } catch (IOException ex) {
            Logger.getLogger(RecentFilesManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (iSConfig == null) {
            return new LinkedList<>();
        }
        LinkedList ListRecentFiles = new LinkedList<>();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(iSConfig));
            String str = null;
            try {
                str = reader.readLine();
            } catch (IOException ex) {
                Logger.getLogger(RecentFilesManager.class.getName()).log(Level.SEVERE, null, ex);
            }
            while (str != null && !"".equals(str)) {
                String[] aux = str.split("!:");
                RecentFile recent = new RecentFile();
                recent.setName(aux[0]);
                recent.setPath(aux[1]);
                ListRecentFiles.add(recent);
                str = reader.readLine();
            }
        } catch (IOException ex) {
            Logger.getLogger(RecentFilesManager.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                iSConfig.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return ListRecentFiles;
    }

    public Integer IndexWithValueEqualOnTheList(RecentFile newRecentFile,
            LinkedList<RecentFile> recentFiles) {
        for (int i = 0; i < recentFiles.size(); i++) {
            if (newRecentFile.getPath().equals(recentFiles.get(i).getPath())) {
                return i;
            }
        }
        return null;
    }

    public void RemoveRecentFile(RecentFile brokenRecentFile) {
        LinkedList<RecentFile> listRecentFiles = ListRecentFiles();
        Integer indexValueEqual = IndexWithValueEqualOnTheList(brokenRecentFile, listRecentFiles);
        listRecentFiles.remove((int) indexValueEqual);
        SaveListOfRecentFiles(listRecentFiles);
    }

    public void AddRecentFile(RecentFile newRecentFile) {
        LinkedList<RecentFile> listRecentFiles = ListRecentFiles();
        Integer indexValueEqual = IndexWithValueEqualOnTheList(newRecentFile, listRecentFiles);
        if (indexValueEqual != null) {
            listRecentFiles.remove((int) indexValueEqual);
        }
        if (listRecentFiles.size() == 10) {
            listRecentFiles.remove(9);
        }
        listRecentFiles.add(0, newRecentFile);
        SaveListOfRecentFiles(listRecentFiles);
    }

    private void SaveListOfRecentFiles(LinkedList<RecentFile> listRecentFiles) {
        File file = new File(caminhoArquivoConfiguracao);
        try {
            file.createNewFile();
        } catch (IOException ex) {
            Logger.getLogger(RecentFilesManager.class.getName())
                    .log(Level.SEVERE, null, ex);
        }
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(file);
            for (RecentFile arquivoRecente : listRecentFiles) {
                writer.println(arquivoRecente.getName() + "!:" + arquivoRecente.getPath());
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(RecentFilesManager.class.getName())
                    .log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }
}
