package Draw;

import Core.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.Serializable;
import javax.swing.BorderFactory;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTextArea;
/*
 * DrawAreaTexto.java
 *
 * Created on 27 de Março de 2008, 11:37
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
import javax.swing.border.Border;

/**
 *
 * @author CCOMP
 */
public class DrawAreaTexto extends JTextArea
        implements Serializable, MouseListener, MouseMotionListener {

    private Rectangle retangulo;
    private Mapa mapa;
    private JMenuItem remove;

    private Border CorNot = BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder());
    private int bordaX, bordaY;

    /**
     * Creates a new instance of DrawAreaTexto
     */
    public DrawAreaTexto(Mapa mapa, int posX, int posY) {
        this.mapa = mapa;
        setBackground(Color.white);
        setFont(new Font("Bitstream Vera Serif", Font.BOLD, 13));

        setLineWrap(true);
        setVisible(true);
        setForeground(Color.BLACK);
        setBorder(CorNot);
        //retangulo.setSize(50,50);       
        //Border(Color.CYAN);
        bordaX = 200;
        bordaY = 150;
        remove = new JMenuItem("Remove");

        createEventosPopUpMenu();

        JPopupMenu menu = new JPopupMenu("Menu");
        menu.add(remove);
        menu.addSeparator();
        setComponentPopupMenu(menu);

        setSize(posX, posY);
        setBounds(posX, posY, 200, 150);
        setLayout(null);

        addMouseListener(this);
        addMouseMotionListener(this);
        setVisible(true);
    }

    public void ganhaFoco() {
        requestFocus();
    }

    public void setBordaX(int bordaX) {
        this.bordaX = bordaX;
    }

    public void setBordaY(int bordaY) {
        this.bordaY = bordaY;
    }

    protected DrawAreaTexto tx = this;

    public void createEventosPopUpMenu() {

        remove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mapa.removeTextArea(tx);
                setVisible(false);
            }
        });

    }

    public void mouseClicked(MouseEvent e) {

    }

    public void mousePressed(MouseEvent e) {

    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
        setBorder(CorNot);
    }

    public void mouseExited(MouseEvent e) {
        setBorder(null);
    }

    //public boolean isPerto(int x, int y){
    //}
    public void mouseDragged(MouseEvent e) {
        if (e.getX() > this.getBounds().getWidth() - 15 && e.getY() > this.getBounds().getHeight() - 15) {
            setBounds(getX(), getY(), e.getX(), e.getY());
            bordaX = e.getX();
            bordaY = e.getY();
        } else {
            retangulo = getBounds();
            int iX = e.getX();
            int iY = e.getY();

            int totX;
            int totY;
            double totalX = retangulo.getX();
            double totalY = retangulo.getY();

            //Variaveis para colocar o objeto no centro da posição clicada
            int largura, altura;
            largura = retangulo.width;
            altura = retangulo.height;

            totX = (iX + (int) totalX) - (largura / 2);
            totY = (iY + (int) totalY) - (altura / 2);

            setBounds(totX, totY, bordaX, bordaY);

            mapa.repaint();
        }
    }

    public void mouseMoved(MouseEvent e) {
        if (e.getX() > this.getBounds().getWidth() - 15 && e.getY() > this.getBounds().getHeight() - 15) {
            setCursor(new java.awt.Cursor(java.awt.Cursor.SE_RESIZE_CURSOR));
        } else {
            setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        }
    }

}
